% compile
if exist('serial_comm.mexmaci64', 'file') ~= 3
    mex serial_comm.c
end

% initialize
% /dev/tty.usbmodem1451
% /dev/tty.HC-06-DevB
% /dev/tty.usbserial-kobuki_A901PEWI
serial_comm('open', '/dev/tty.usbserial-kobuki_A901PEWI');

% set speed
serial_comm('set_speed', 100, 0)