#ifndef SERIAL_COMM_H
#define SERIAL_COMM_H

#define TURTLEBOT

// Choose the port type.

#ifndef TURTLEBOT
#define USB_SERIAL_PORT "/dev/tty.usbmodem1451"
//#define USB_SERIAL_PORT "/dev/tty.HC-06-DevB"

// Set speed interface
void set_speed(int translational_speed, int rotational_speed);

#else
#define USB_SERIAL_PORT "/dev/tty.usbserial-kobuki_A901PEWI"

void set_speed(short speed, short radius);

#endif

extern int port_fd;


// Serial communication interface
int init_serial_input (char* port);


#endif
