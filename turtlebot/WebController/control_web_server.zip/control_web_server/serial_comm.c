//
//  main.cpp
//  control_robot
//
//  Created by Linguang on 7/11/14.
//  Copyright (c) 2014 Linguang. All rights reserved.
//

//#include <iostream>
#include <unistd.h>
#include <fcntl.h>
#include <termios.h>
//#include <stdio.h>
//#include <stdlib.h>
#include <ncurses.h>

#include "serial_comm.h"

//using namespace std;

#define START_BYTE          0xAA
#define END_BYTE            0xBB

//for turtlebot
#define HEADER0             0xAA
#define HEADER1             0x55
#define CMD                 0x01


#ifndef TURTLEBOT
unsigned char packet[4] = {(unsigned char)START_BYTE, 0, 0, (unsigned char)END_BYTE};
#else
unsigned char packet[10] = {(unsigned char)HEADER0, (unsigned char)HEADER1,
                            (unsigned char)0x06, (unsigned char)CMD, (unsigned char)0x04,
                            0, 0, 0, 0, 0};
#endif

int port_fd;


int init_serial_input (char* port) {
    int fd = 0;
    struct termios options;

    fd = open(port, O_RDWR | O_NOCTTY | O_NDELAY);
    if (fd == -1)
        return fd;
    fcntl(fd, F_SETFL, 0);    // clear all flags on descriptor, enable direct I/O
    tcgetattr(fd, &options);   // read serial port options
    //set baud rate
#ifndef TURTLEBOT
    cfsetispeed(&options, B9600);
    cfsetospeed(&options, B9600);
#else
    cfsetispeed(&options, B115200);
    cfsetospeed(&options, B115200);
#endif
    options.c_cflag |= (CLOCAL | CREAD);
    options.c_cflag &= ~PARENB;
    options.c_cflag &= ~CSTOPB;
    options.c_cflag &= ~CSIZE;
    options.c_cflag |= CS8;
    tcsetattr(fd, TCSANOW, &options);
    return fd;
}

#ifndef TURTLEBOT

void set_speed(int translational_speed, int rotational_speed){
  if(translational_speed >= 0){
      packet[1] = (unsigned char)translational_speed;
  }else{
      packet[1] = (unsigned char)(-translational_speed);
      packet[1] = packet[1] | 0b10000000;
  }

  if(rotational_speed >= 0){
      packet[2] = (unsigned char)rotational_speed;
  }else{
      packet[2] = (unsigned char)(-rotational_speed);
      packet[2] = packet[2] | 0b10000000;
  }
  write(port_fd, packet, 4);
}

#else

void set_speed(short speed, short radius){
  unsigned char checksum = 0;
  packet[5] = (unsigned char)(speed & 0x00FF);
  packet[6] = (unsigned char)(speed >> 8);
  packet[7] = (unsigned char)(radius & 0x00FF);
  packet[8] = (unsigned char)(radius >> 8);
  for (int i = 2; i < 9; i++){
    checksum ^= packet[i];
  }
  packet[9] = checksum;
  write(port_fd, packet, 10);
}
#endif

/*
int main(int argc, const char * argv[])
{
    port_fd = init_serial_input((char* )USB_SERIAL_PORT);
    // serial is checked
    if (port_fd == -1)  {
        cout << "Couldn't open USB port" << endl;
    }else{
        cout << "Port opened " << port_fd << endl;


        char ch;

        while (1) {
            ch = getchar();
            if (ch == 'w'){
                packet[1] = (unsigned char)TRANSLATION_SPEED;
                packet[2] = (unsigned char)0;
                write(port_fd, packet, 4);
            }
            else if (ch == 's'){
                packet[1] = (unsigned char)TRANSLATION_SPEED;
                packet[1] = packet[1] | 0b10000000;
                packet[2] = (unsigned char)0;
                write(port_fd, packet, 4);
            }
            else if (ch == 'd'){
                packet[1] = 0;
                packet[2] = (unsigned char)ROTATION_SPEED;
                write(port_fd, packet, 4);
            }
            else if (ch == 'a'){
                packet[1] = 0;
                packet[2] = (unsigned char)ROTATION_SPEED;
                packet[2] = packet[2] | 0b10000000;
                write(port_fd, packet, 4);
            }
            else if (ch == 'x'){
                packet[1] = 0;
                packet[2] = 0;
                write(port_fd, packet, 4);
            }
            else if (ch == 'o'){
                TRANSLATION_SPEED = TRANSLATION_SPEED + 10;
            }
            else if (ch == 'l'){
                TRANSLATION_SPEED = TRANSLATION_SPEED - 10;
            }
            else if (ch == 'q'){
                break;
            }

        }

    }
    return 0;
}
*/
