Two simple functions to plot a curve or a histogram in polar coordinate.

visualizePolar.m     : plot a compass-like prediction confidence score. See the 2nd Column in Figure 8 for example.
visualizePolarHist.m : plot a polar histogram as shown in the 4-th row of Figure 6 in the paper.

Please cite this paper if you use this code:
J. Xiao, K. A. Ehinger, A. Oliva and A. Torralba
Recognizing Scene Viewpoint using Panoramic Place Representation
Proceedings of 25th IEEE Conference on Computer Vision and Pattern Recognition (CVPR2012)

License: The MIT License (MIT) http://www.opensource.org/licenses/MIT

