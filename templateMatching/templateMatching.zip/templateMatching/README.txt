This piece of code is to demonstrait simple HOG sliding window template matching.

Written by Jianxiong Xiao

Usage: Open and run demo.m

Please cite this paper if you used the code:
J. Xiao, J. Hays, K. Ehinger, A. Oliva, and A. Torralba 
SUN Database: Large-scale Scene Recognition from Abbey to Zoo 
Proceedings of 23rd IEEE Conference on Computer Vision and Pattern Recognition (CVPR2010)

