function showHOG(w)

hogim = HOGpicture(w);
imagesc(hogim)
axis image
axis off
grid on
drawnow
