/*
Efficient Loopy Belief Propagation on GPU

This is a GPU implementation of the following paper:

Efficient Belief Propagation for Early Vision.
Pedro F. Felzenszwalb and Daniel P. Huttenlocher.
International Journal of Computer Vision, Vol. 70, No. 1, October 2006.

The implementation is based on the CPU versio provided at
http://people.cs.uchicago.edu/~pff/bp/

XIAO Jianxiong

Testing Compiler: Microsoft Visual Studio 2005, Cg, Opengl, Glew
Testing Environment: ATI Radeon X1300PRO with 256MB
*/

#include <cstdio>
#include <iostream>
#include <algorithm>
#include <assert.h>
#include "image.h"
#include "misc.h"
#include "pnmfile.h"
#include "filter.h"
#include "imconv.h"
#include "gpgpu.h"
#include "mytime.h"

#define ITER 4				// number of BP iterations at each scale
#define LEVELS 5			// number of scales

#define DISC_K 1.7F         // truncation of discontinuity cost
#define DATA_K 15.0F        // truncation of data cost
#define LAMBDA 0.07F        // weighting of data cost
#define DELTA  1.0F

#define INF 1E20			// large cost
#define VALUES 16			// number of possible disparities
#define SCALE 16			// scaling from disparity to graylevel in output

#define SIGMA 0.7			// amount to smooth the input images
#define GPUSCALE 1.0f

double totaltime;
GLuint glutWindowHandle;
GLuint fb;

// computation of data costs
image<float[VALUES]> *comp_data(image<uchar> *img1, image<uchar> *img2)
{
	int width = img1->width();
	int height = img1->height();
	image<float[VALUES]> *data = new image<float[VALUES]>(width, height);

	image<float> *sm1, *sm2;
	if (SIGMA >= 0.1)
	{
		sm1 = smooth(img1, SIGMA);
		sm2 = smooth(img2, SIGMA);
	} else
	{
		sm1 = imageUCHARtoFLOAT(img1);
		sm2 = imageUCHARtoFLOAT(img2);
	}

	for (int y = 0; y < height; y++)
	{
		for (int x = VALUES-1; x < width; x++)
		{
			for (int value = 0; value < VALUES; value++)
			{
				float val = abs(imRef(sm1, x, y)-imRef(sm2, x-value, y));
				imRef(data, x, y)[value] = LAMBDA * min(val, DATA_K);
			}
		}
	}

	delete sm1;
	delete sm2;
	return data;
}

// generate output from current messages
image<uchar> *output(image<float[VALUES]> *u, image<float[VALUES]> *d,
					 image<float[VALUES]> *l, image<float[VALUES]> *r,
					 image<float[VALUES]> *data)
{
	int width = data->width();
	int height = data->height();
	image<uchar> *out = new image<uchar>(width, height);

	for (int y = 1; y < height-1; y++)
	{
		for (int x = 1; x < width-1; x++)
		{
			// keep track of best value for current pixel
			int best = 0;
			float best_val = INF;
			for (int value = 0; value < VALUES; value++)
			{
				float val =
					imRef(u, x, y+1) [value] +
					imRef(d, x, y-1) [value] +
					imRef(l, x+1, y) [value] +
					imRef(r, x-1, y) [value] +
					imRef(data, x, y)[value];
				if (val < best_val)
				{
					best_val = val;
					best = value;
				}
			}
			imRef(out, x, y) = best * SCALE;
		}
	}
	return out;
}

// dt of 1d function
static void dt(float f[VALUES])
{
	for (int q = 1; q < VALUES; q++)
	{
		float prev = f[q-1] + DELTA;
		if (prev < f[q])
			f[q] = prev;
	}
	for (int q = VALUES-2; q >= 0; q--)
	{
		float prev = f[q+1] + DELTA;
		if (prev < f[q])
			f[q] = prev;
	}
}


// CPU compute message
void CPUmsg(float s1[VALUES], float s2[VALUES],
		 float s3[VALUES], float s4[VALUES],
		 float dst[VALUES])
{
	float val;

	// aggregate and find min
	float minimum = INF;
	for (int value = 0; value < VALUES; value++)
	{
		dst[value] = s1[value] + s2[value] + s3[value] + s4[value];
		if (dst[value] < minimum)
			minimum = dst[value];
	}

	// dt
	dt(dst);

	// truncate
	minimum += DISC_K;
	for (int value = 0; value < VALUES; value++)
		if (minimum < dst[value])
			dst[value] = minimum;

	// normalize
	val = 0;
	for (int value = 0; value < VALUES; value++)
		val += dst[value];

	val /= VALUES;
	for (int value = 0; value < VALUES; value++)
		dst[value] -= val;

}

//CPU belief propagation using checkerboard update scheme
void CPUbp_cb(image<float[VALUES]> *u, image<float[VALUES]> *d,
			  image<float[VALUES]> *l, image<float[VALUES]> *r,
			  image<float[VALUES]> *data,
			  int iter)
{
	int width = data->width();
	int height = data->height();

	double start, end ;

	// time marker: start
	start = myTime() ;
	for (int t = 0; t < ITER; t++)
	{
		std::cout << "iter " << t << "\n";
		for (int y = 1; y < height-1; y++)
		{
			for (int x = ((y+t) % 2) + 1; x < width-1; x+=2)
			{
				CPUmsg(imRef(u, x, y+1),imRef(l, x+1, y),imRef(r, x-1, y),imRef(data, x, y), imRef(u, x, y));
				CPUmsg(imRef(d, x, y-1),imRef(l, x+1, y),imRef(r, x-1, y),imRef(data, x, y), imRef(d, x, y));
				CPUmsg(imRef(u, x, y+1),imRef(d, x, y-1),imRef(r, x-1, y),imRef(data, x, y), imRef(r, x, y));
				CPUmsg(imRef(u, x, y+1),imRef(d, x, y-1),imRef(l, x+1, y),imRef(data, x, y), imRef(l, x, y));
			}
		}
	}
	// time marker: end
	end = myTime() ;
	// report the elapsed time
	totaltime += end - start;
}

//GPU belief propagation using pingpong update scheme with MRT division
void GPUbp_16labels(image<float[VALUES]> *u, image<float[VALUES]> *d,
					image<float[VALUES]> *l, image<float[VALUES]> *r,
					image<float[VALUES]> *data,
					int iter)
{

	int i;
	int h,v;
	int N;
	// ------------------------------ Setup GL GLUT GLEW FBO ---------------------------------
			int hImg = data->width();
			int vImg = data->height();
			N = vImg * hImg * 4;

			float* likelihood[4];
			for(int i=0;i<4;i++)
				likelihood[i]  = (float*)malloc(N*sizeof(float));

			for(v=1;v<vImg-1;v++)
			{
				for(h=1;h<hImg-1;h++)
				{
					for(int j=0;j<4;j++)
						for(int i=0;i<4;i++)
						{
							likelihood[j][(v*hImg+h)*4+i] = imRef(data, h, v)[j*4+i] * GPUSCALE ;

							//if(v>199 && v<201 && h>199 && h<201)
							//	std::cout<< likelihood[j][(v*hImg+h)*4+i] <<"\n";
						}
				}
			}
			N *= 4;

			float* initMessage[4];
			for(int i=0;i<4;i++)
				initMessage[i] = (float*)malloc(N*sizeof(float));

			for(int v=0;v<vImg;v++)
				for(int h=0;h<hImg;h++)
					for(int i=0;i<4;i++)
						for(int j=0;j<4;j++)
						{
							initMessage[i][ ((2*v+1)* 2*hImg + (2*h+1))*4 + j]=imRef(r, h, v)[i*4+j]; //R
							initMessage[i][ ((2*v  )* 2*hImg + (2*h  ))*4 + j]=imRef(l, h, v)[i*4+j]; //L
							initMessage[i][ ((2*v+1)* 2*hImg + (2*h  ))*4 + j]=imRef(d, h, v)[i*4+j]; //B
							initMessage[i][ ((2*v  )* 2*hImg + (2*h+1))*4 + j]=imRef(u, h, v)[i*4+j]; //T
						}

			vImg *= 2;
			hImg *= 2;

			gpgpu_initViewport(&glutWindowHandle,&fb, hImg,vImg);

	// ----------------------------------- Create Texture --------------------------------------

		// Data Likelihood Texture ---------------------------------------------------------------------------
			// create texture
			GLuint DTexID[4];
			glGenTextures (4, DTexID);
			for(int i=0;i<4;i++)
			{
				gpgpu_textureSetup		(DTexID[i],hImg/2,vImg/2);
				gpgpu_writeToTexture	(DTexID[i],hImg/2,vImg/2,likelihood[i]);
			}

		// Message Texture ---------------------------------------------------------------------------

			GLuint mTexID[2][4];
			glGenTextures (4, mTexID[0]);
			glGenTextures (4, mTexID[1]);
			for(int i=0;i<4;i++)
			{
				gpgpu_textureSetup	(mTexID[0][i],hImg,vImg);
				gpgpu_textureSetup	(mTexID[1][i],hImg,vImg);
				gpgpu_writeToTexture(mTexID[0][i],hImg,vImg,initMessage[i]);
				gpgpu_writeToTexture(mTexID[1][i],hImg,vImg,initMessage[i]);
			}

		// set texenv mode from modulate (the default) to replace)
			glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_REPLACE);

	// -------------------------- Setting up the Cg runtime ------------------------------------

		// Cg vars
		CGprofile fragmentProfile;
		CGprogram fragmentProgram;

		// set up Cg
		cgContext = cgCreateContext();
		cgSetErrorCallback(cgErrorCallback);
		fragmentProfile = cgGLGetLatestProfile(CG_GL_FRAGMENT);
		cgGLSetOptimalOptions(fragmentProfile);
		//std::cout<<cgGetProfileString(fragmentProfile)<<std::endl;

		// create fragment program
		const char* compilerArguments[] = {"-po", "ATI_draw_buffers", 0};
		fragmentProgram = cgCreateProgramFromFile(
		  cgContext,				/* Cg runtime context */
		  CG_SOURCE,                /* Program in human-readable form */
		  "bp16labels.cg",			/* Name of file containing program */
		  fragmentProfile,			/* Profile: OpenGL ARB vertex program */
		  "bp16labels",				/* Entry function name */
		  compilerArguments);       /* extra compiler options */
		// load program
		cgGLLoadProgram (fragmentProgram);

		/*std::cout<<*/cgGetProgramString(fragmentProgram, CG_COMPILED_PROGRAM);
		//int pos;
		//glGetIntegerv(GL_PROGRAM_ERROR_POSITION_ARB, &pos);
		//std::cout<<"Error Position = "<<pos<<std::endl;
		//std::cout<<cgGetProfileString(fragmentProfile)<<std::endl;

		// and get parameter handles by name
		CGparameter inMLParam, inMRParam, inMTParam, inMBParam;
		inMLParam = cgGetNamedParameter (fragmentProgram,"inM0");
		inMRParam = cgGetNamedParameter (fragmentProgram,"inM1");
		inMTParam = cgGetNamedParameter (fragmentProgram,"inM2");
		inMBParam = cgGetNamedParameter (fragmentProgram,"inM3");

		CGparameter sParam, dParam;
		CGparameter DParam[4];
		sParam = cgGetNamedParameter (fragmentProgram,"s");
		dParam = cgGetNamedParameter (fragmentProgram,"d");
		DParam[0] = cgGetNamedParameter (fragmentProgram,"D0");
		DParam[1] = cgGetNamedParameter (fragmentProgram,"D1");
		DParam[2] = cgGetNamedParameter (fragmentProgram,"D2");
		DParam[3] = cgGetNamedParameter (fragmentProgram,"D3");

	// -------------------------- Preparing the computational kernel ----------------------------
		// enable fragment profile
		cgGLEnableProfile(fragmentProfile);
		// bind program
		cgGLBindProgram(fragmentProgram);

		// ------------------------------ Setting input arrays / textures ----------------------------
			// enable texture x (read-only) and uniform parameter [...]
			// enable read-only texture
			cgGLSetTextureParameter		(DParam[0],	DTexID[0]);				cgGLEnableTextureParameter	(DParam[0]);
			cgGLSetTextureParameter		(DParam[1],	DTexID[1]);				cgGLEnableTextureParameter	(DParam[1]);
			cgGLSetTextureParameter		(DParam[2],	DTexID[2]);				cgGLEnableTextureParameter	(DParam[2]);
			cgGLSetTextureParameter		(DParam[3],	DTexID[3]);				cgGLEnableTextureParameter	(DParam[3]);
			// enable scalar alpha
			cgSetParameter1f(sParam, DELTA * GPUSCALE);
			cgSetParameter1f(dParam, DISC_K  * GPUSCALE);

		float** result = new float*[4];
		for(i=0;i<4;i++)
			result[i] = new float[N];

		int source = 0;

		double start, end ;

		// time marker: start
		start = myTime() ;

		// iterate computation several times
		for (int t = 0; t < ITER; t++)
		{
			// ------------------------------ Setting output arrays / textures ----------------------------
				// attach two textures to FBO
				for (int i=0; i<4; i++)
					glFramebufferTexture2DEXT(GL_FRAMEBUFFER_EXT, buffers[i], textarget, mTexID[1-source][i], 0);
				checkFramebufferStatus();
				checkGLErrors("bind output");
				// set render destination // set the texture as render target	// set render destination
				glDrawBuffers(4,buffers);
				checkFramebufferStatus();
				checkGLErrors("set render destination");
			// ------------------------------ Setting input arrays / textures ----------------------------
				// enable read-only texture
				cgGLSetTextureParameter		(inMLParam, mTexID[source][0]);		cgGLEnableTextureParameter	(inMLParam);
				cgGLSetTextureParameter		(inMRParam, mTexID[source][1]);		cgGLEnableTextureParameter	(inMRParam);
				cgGLSetTextureParameter		(inMTParam, mTexID[source][2]);		cgGLEnableTextureParameter	(inMTParam);
				cgGLSetTextureParameter		(inMBParam, mTexID[source][3]);		cgGLEnableTextureParameter	(inMBParam);
			// ------------------------------ Performing the computation -----------------------------------
				gpgpu_run(hImg,vImg);
			// ------------------------------ Swap ---------------------------------------------------------
				source = 1 - source;
		}

		// time marker: end
		end = myTime() ;
		totaltime += end - start;



		for(i=0;i<4;i++)
		{
			glReadBuffer(buffers[i]);
			glReadPixels(0, 0, hImg, vImg,texFormat,GL_FLOAT,result[i]);
		}
	// ----------------------------- Read Back the Computed Result ---------------------------------
		hImg /= 2;
		vImg /= 2;

		for(int v=0;v<vImg;v++)
			for(int h=0;h<hImg;h++)
				for(int i=0;i<4;i++)
					for(int j=0;j<4;j++)
					{
						imRef(r, h, v)[i*4+j] = result[i][ ((2*v+1)* 2*hImg + (2*h+1))*4 + j] / GPUSCALE; //R
						imRef(l, h, v)[i*4+j] = result[i][ ((2*v  )* 2*hImg + (2*h  ))*4 + j] / GPUSCALE; //L
						imRef(d, h, v)[i*4+j] = result[i][ ((2*v+1)* 2*hImg + (2*h  ))*4 + j] / GPUSCALE; //B
						imRef(u, h, v)[i*4+j] = result[i][ ((2*v  )* 2*hImg + (2*h+1))*4 + j] / GPUSCALE; //T
					}

		for(i=0;i<4;i++)
			delete []  result[i];
		delete []  result;

	// ----------------------------------------- clean up -------------------------------------------

		glDeleteFramebuffersEXT(1,&fb);
		for(int i=0;i<4;i++)
			free(likelihood[i]);
		for(int i=0;i<4;i++)
			free(initMessage[i]);
		glDeleteTextures (4,mTexID[0]);
		glDeleteTextures (4,mTexID[1]);
		glDeleteTextures (4,DTexID);
		glutDestroyWindow (glutWindowHandle);
}


// multiscale belief propagation for stereo
image<uchar> *stereo_ms(image<uchar> *img1, image<uchar> *img2, bool bGPU)
{
  image<float[VALUES]> *u[LEVELS];
  image<float[VALUES]> *d[LEVELS];
  image<float[VALUES]> *l[LEVELS];
  image<float[VALUES]> *r[LEVELS];
  image<float[VALUES]> *data[LEVELS];


  // data costs
  data[0] = comp_data(img1, img2);

  // data pyramid
  for (int i = 1; i < LEVELS; i++)
  {
	  int old_width = data[i-1]->width();
	  int old_height = data[i-1]->height();
	  int new_width = (int)ceil(old_width/2.0);
	  int new_height = (int)ceil(old_height/2.0);
	  assert(new_width >= 1);	  assert(new_height >= 1);

	  data[i] = new image<float[VALUES]>(new_width, new_height);
	  for (int y = 0; y < old_height; y++)
	  {
		  for (int x = 0; x < old_width; x++)
		  {
			  for (int value = 0; value < VALUES; value++)
			  {
				  imRef(data[i], x/2, y/2)[value] += imRef(data[i-1], x, y)[value];
			  }
		  }
	  }
  }

  totaltime = 0.0;
  if(bGPU)
  {
	  gpgpu_initWindow();
  }

  // run bp from coarse to fine
  for (int i = LEVELS-1; i >= 0; i--)
  {
	  int width = data[i]->width();
	  int height = data[i]->height();
	  // allocate & init memory for messages
	  if (i == LEVELS-1)
	  {
		  // in the coarsest level messages are initialized to zero
		  u[i] = new image<float[VALUES]>(width, height);
		  d[i] = new image<float[VALUES]>(width, height);
		  l[i] = new image<float[VALUES]>(width, height);
		  r[i] = new image<float[VALUES]>(width, height);
	  } else
	  {
		  // initialize messages from values of previous level
		  u[i] = new image<float[VALUES]>(width, height, false);
		  d[i] = new image<float[VALUES]>(width, height, false);
		  l[i] = new image<float[VALUES]>(width, height, false);
		  r[i] = new image<float[VALUES]>(width, height, false);

		  for (int y = 0; y < height; y++)
		  {
			  for (int x = 0; x < width; x++)
			  {
				  for (int value = 0; value < VALUES; value++)
				  {
					  imRef(u[i], x, y)[value] = imRef(u[i+1], x/2, y/2)[value];
					  imRef(d[i], x, y)[value] = imRef(d[i+1], x/2, y/2)[value];
					  imRef(l[i], x, y)[value] = imRef(l[i+1], x/2, y/2)[value];
					  imRef(r[i], x, y)[value] = imRef(r[i+1], x/2, y/2)[value];
				  }
			  }
		  }
		  // delete old messages and data
		  delete u[i+1];
		  delete d[i+1];
		  delete l[i+1];
		  delete r[i+1];
		  delete data[i+1];
	  }

	  // BP
	  if(!bGPU)
		  CPUbp_cb(u[i], d[i], l[i], r[i], data[i], ITER);
	  else
	  {
		  if(VALUES==16)
			  GPUbp_16labels(u[i], d[i], l[i], r[i], data[i], 1+2*(ITER-1));
		  else
			  std::cout<<"GPU Version Not Supported for # of Depth Label = "<<VALUES<<std::endl;
	  }
  }

	std::cout<< "Time Cost = " << totaltime <<" seconds\n"; // report the elapsed time


  image<uchar> *out = output(u[0], d[0], l[0], r[0], data[0]);

  delete u[0];
  delete d[0];
  delete l[0];
  delete r[0];
  delete data[0];

  return out;
}

int main(int argc, char **argv)
{
	std::cout<<"--------------------------------------------------"	<<std::endl;
	std::cout<<"HKUST COMP641M Final Project -- BP Stereo"			<<std::endl;
	std::cout<<"Instructor:  Dr. Pedro V. Sander"					<<std::endl;
	std::cout<<"Student:     XIAO, Jianxiong 05556262 csxjx@ust.hk"	<<std::endl;
	std::cout<<"Environment: ATI Radeon X1300PRO with 256MB"		<<std::endl;
	std::cout<<"--------------------------------------------------"	<<std::endl;

	image<uchar> *img1, *img2, *out;

	if (argc != 4)
	{
		std::cerr << "usage: " << argv[0] << " left(pgm) right(pgm) out(pgm)\n";
		exit(1);
	}

	// load input
	img1 = loadPGM(argv[1]);
	img2 = loadPGM(argv[2]);

	std::cout<<"0. Use CPU"<<std::endl;
	std::cout<<"1. Use GPU"<<std::endl;
	std::cout<<"Please choose 0 or 1: ";

	int nGPU;
	std::cin >> nGPU;

	// compute disparities
	out = stereo_ms(img1, img2, (nGPU==1));

	// save output
	savePGM(out, argv[3]);

	delete img1;
	delete img2;
	delete out;
	return 0;
}
