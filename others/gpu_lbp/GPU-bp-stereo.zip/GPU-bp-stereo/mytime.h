#include <windows.h>

// Difference in successive myTime() calls tells you the elapsed time
// - return time in seconds
double myTime()
{ 
    //////////////////////////////////////////////////////
    // WIN32: use QueryPerformance (very accurate)
    //////////////////////////////////////////////////////

    LARGE_INTEGER freq , t ;

    // freq is the clock speed of the CPU
    QueryPerformanceFrequency ( & freq ) ;

	//cout << "freq = " << ((double) freq.QuadPart) << endl ;

    // t is the high resolution performance counter (see MSDN)
    QueryPerformanceCounter ( & t ) ;

    return ( t.QuadPart /(double) freq.QuadPart ) ;
}
