Efficient Loopy Belief Propagation on GPU

This is a GPU implementation of the following paper

Efficient Belief Propagation for Early Vision.
Pedro F. Felzenszwalb and Daniel P. Huttenlocher.
International Journal of Computer Vision, Vol. 70, No. 1, October 2006.

The implementation is based on the CPU versio provided at 
http://people.cs.uchicago.edu/~pff/bp/

Testing Compiler: Microsoft Visual Studio 2005, Cg, Opengl, Glew
Testing Environment: ATI Radeon X1300PRO with 256MB

XIAO Jianxiong
http://www.cse.ust.hk/~csxjx/