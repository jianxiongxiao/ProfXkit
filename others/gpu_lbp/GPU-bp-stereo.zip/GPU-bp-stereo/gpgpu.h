#ifndef GPGPU_H
#define GPGPU_H

#include <stdio.h>
#include <stdlib.h>
#include <GL/glew.h>
#include <GL/glut.h>
#include <Cg/cgGL.h>
#include <math.h>

static GLenum textarget = GL_TEXTURE_RECTANGLE_ARB;
static GLenum texinternalformat = GL_RGBA32F_ARB;
static GLenum texFormat = GL_RGBA;

CGcontext cgContext;

// output buffer identifiers
// you have been warned to change these, since a lot is 
// hard-coded. Also, more than four outputs are not supported
// on any hardware at the time of writing.
GLenum buffers[4] =    { GL_COLOR_ATTACHMENT0_EXT, 
						 GL_COLOR_ATTACHMENT1_EXT, 
						 GL_COLOR_ATTACHMENT2_EXT, 
						 GL_COLOR_ATTACHMENT3_EXT};

/**
 * Callback for Cg errors
 */
void cgErrorCallback(void)
{
    CGerror lastError = cgGetError();
    if(lastError)
	{
		printf(cgGetErrorString(lastError));
		printf(cgGetLastListing(cgContext));
		exit(1);
    }
} 

/**
 * Checks for OpenGL errors.
 * Extremely useful debugging function: When developing, 
 * make sure to call this after almost every GL call.
 */
void checkGLErrors (const char *label)
{
    GLenum errCode;
    const GLubyte *errStr;
    if ((errCode = glGetError()) != GL_NO_ERROR) {
		errStr = gluErrorString(errCode);
		printf("OpenGL ERROR: ");
		printf((char*)errStr);
		printf("(Label: ");
		printf(label);
		printf(")\n.");
    }
}

/**
 * Checks framebuffer status.
 * Copied directly out of the spec, modified to deliver a return value.
 */
bool checkFramebufferStatus()
{
    GLenum status;
    status = (GLenum) glCheckFramebufferStatusEXT(GL_FRAMEBUFFER_EXT);
    switch(status) {
		case GL_FRAMEBUFFER_COMPLETE_EXT:
		return true;
		case GL_FRAMEBUFFER_INCOMPLETE_ATTACHMENT_EXT:
		printf("Framebuffer incomplete, incomplete attachment\n");
		return false;
		case GL_FRAMEBUFFER_INCOMPLETE_MISSING_ATTACHMENT_EXT:
		printf("Framebuffer incomplete, missing attachment\n");
		return false;
		case GL_FRAMEBUFFER_INCOMPLETE_DIMENSIONS_EXT:
		printf("Framebuffer incomplete, attached images must have same dimensions\n");
		return false;
		case GL_FRAMEBUFFER_INCOMPLETE_FORMATS_EXT:
		printf("Framebuffer incomplete, attached images must have same format\n");
		return false;
		case GL_FRAMEBUFFER_INCOMPLETE_DRAW_BUFFER_EXT:
		printf("Framebuffer incomplete, missing draw buffer\n");
		return false;
		case GL_FRAMEBUFFER_INCOMPLETE_READ_BUFFER_EXT:
		printf("Framebuffer incomplete, missing read buffer\n");
		return false;
		case GL_FRAMEBUFFER_UNSUPPORTED_EXT:
		printf("Unsupported framebuffer format\n");
		return false;
	}
    return false;
}


void gpgpu_run(int hImg,int vImg)
{
	// For Texture 2D
	// make quad filled to hit every pixel/texel
	glPolygonMode(GL_FRONT,GL_FILL);
	// and render quad
	glBegin(GL_QUADS);
		glTexCoord2f	(1.0, 1.0); 
		glVertex2f		(1.0, 1.0);
		glTexCoord2f	(hImg-1.0, 1.0); 
		glVertex2f		(hImg-1.0, 1.0);
		glTexCoord2f	(hImg-1.0, vImg-1.0);
		glVertex2f		(hImg-1.0, vImg-1.0);
		glTexCoord2f	(1.0, vImg-1.0); 
		glVertex2f		(1.0, vImg-1.0);
	glEnd();
	checkFramebufferStatus();
	checkGLErrors("render()");
}

void gpgpu_textureSetup(GLuint TexID,int hImg,int vImg)
{
	// make active and bind
	glBindTexture(textarget,TexID);
	// set texture parameters
	glTexParameteri(textarget, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
	glTexParameteri(textarget, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
	glTexParameteri(textarget, GL_TEXTURE_WRAP_S, GL_CLAMP);
	glTexParameteri(textarget, GL_TEXTURE_WRAP_T, GL_CLAMP);
	// define texture with floating point format
	glTexImage2D(textarget,0,texinternalformat,hImg,vImg,0,texFormat,GL_FLOAT,0);
}

void gpgpu_writeToTexture(GLuint TexID,int hImg,int vImg,float* pdata)
{
	//Transfers data to texture
	glFramebufferTexture2DEXT(GL_FRAMEBUFFER_EXT, GL_COLOR_ATTACHMENT0_EXT, textarget, TexID, 0);
	glDrawBuffer(GL_COLOR_ATTACHMENT0_EXT);
	glRasterPos2i(0,0);
	glDrawPixels(hImg,vImg,texFormat,GL_FLOAT,pdata);
	glFramebufferTexture2DEXT(GL_FRAMEBUFFER_EXT, GL_COLOR_ATTACHMENT0_EXT, textarget, 0, 0);
}

void gpgpu_initWindow()
{
	// set up glut to get valid GL context and 
	// get extension entry points
	char* dummyChar = "GPGPU";
	char** dummyPointer = & dummyChar;
	int dummyInt =1;
	glutInit (&dummyInt,dummyPointer);
}

void gpgpu_initViewport(GLuint* pGlutWindowHandle,GLuint* pfb, int hImg,int vImg)
{
	// handle to offscreen "window", only used to properly shut down the app
	*pGlutWindowHandle = glutCreateWindow("GPGPU");
	glewInit();
	// viewport transform for 1:1 pixel=texel=data mapping
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluOrtho2D(0.0,hImg,0.0,vImg);
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	glViewport(0,0,hImg,vImg);
	// create FBO and bind it (that is, use offscreen render target)
	glGenFramebuffersEXT(1,pfb); 
	glBindFramebufferEXT(GL_FRAMEBUFFER_EXT,*pfb);
}


#endif
