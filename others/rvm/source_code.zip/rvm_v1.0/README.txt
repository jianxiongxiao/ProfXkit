RVM++: Relevance Vector Machine in C++ by XIAO Jianxiong

### Usage ###

1. 1D Regression Demo:
	cd into the "bin" directory, and run Regression1D_Demo without any arguments.
	The program will automatically load "data/sin.txt" for training.


2. 2D Classification Demo:
	cd into the "bin" directory, and run Classification2D_Demo without any arguments.
	The program will automatically load "data/RipleySynthetic.txt" for training.


3. RVMclassifier:

Usage: RVMclassifier Training.file Testing.file Out.file 
	[Kernel=+gauss Width=.5 InitAlpha=(1/N)^2 MaxIts=500]

Example:
	RVMClassifier ../data/iris_train.txt ../data/iris_test.txt ../data/iris_test_out.txt

4. RVMregressor:

Usage: RVMregressor Training.file Testing.file Out.file 
	[Kernel=+gauss Width=.5 InitAlpha=(1/N)^2 InitBeta=STD/10 MaxIts=500]

Example:
	RVMregressor ../data/sin.txt ../data/sin.txt ../data/sin_test_out.txt


5. A script to run all examples in the document.

	all_rvm_win.bat for Windows.
	all_rvm_linux.bat for GNU/Linux.


### Compiling ###

In Windows:

	Use Visual Studio to open RVM.dsw in src directory. Select the active project, and build.
	I only test it on Microsoft Visual Studio 6.0 with Windows XP sp3.

In GNU/Linux:

	cd into src directory, and make (or gmake)
	I only test it on GNU GCC version 2.95.3 and 4.1.2 with Puppy Linux 3.01 (kernel 2.6.18.1).

### Bugs ###

If you find bugs, etc., feel free to drop me a line. You can find my contact data on:

	http://www.cse.ust.hk/~csxjx/


### File Organization ###

	bin:  all executable files are here. Precompiled binary files have been stored here for windows and linux.

	src:  all source code and makefile are here.

	doc:  a report to detail some implementation issue and comparision with SVM classificiation.

	data: all data used in the above report.

	LibSVM_win: The SVM part of the experiments descirbed in the report.


### LICENSE ###

	RVM++: Relevance Vector Machine in C++

	Copyright (C) 2008 XIAO Jianxiong

	This program is free software: you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation, either version 3 of the License, or
	(at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with this program.  If not, see <http://www.gnu.org/licenses/>.
