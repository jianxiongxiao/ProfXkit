/* RVM++: Relevance Vector Machine in C++
 *
 * Copyright (C) 2008 XIAO Jianxiong
 *
 * http://www.cse.ust.hk/~csxjx/
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include "psplot.h"
#include <iostream>
using namespace std;
#include "RVMregressor.h"
using namespace RVM;

int main()
{
	cout << "Relevance Vector Machine Demo in C++ by XIAO Jianxiong @ April 19th, 2008" <<endl;

	RVMdataset* training = new RVMdataset("..//data//sin.txt");

	//Default parameters
	unsigned int maxIts = 1000;
	double tmpDouble = 1.0/ double(training->GetSize());
	double initAlpha = tmpDouble * tmpDouble;
	double epsilon= training->OldLabelSTD()/10.0;
	double initBeta = 1.0/ (epsilon * epsilon);
	char kernelname[256]="+gauss";
	double width = 3;
	bool withBias = false;
	int scale =10;

	if (kernelname[0]=='+')
	{
		unsigned int i=0;
		while (kernelname[i]!='\0')
		{
			kernelname[i] = kernelname[i+1];
			++i;
		}
		withBias = true;
	}

	//Train the model
	RVMkernel* kernel = new RVMkernel(kernelname,width);
	RVMregressor * regressor = new RVMregressor(training,kernel,maxIts,withBias,initAlpha,initBeta);

	//Train
	regressor->train();

	//Plot
	double x0min,x0max,x1min,x1max;
	x0min = x0max = (*training)(0)->GetFeature_(0);
	x1min = x1max = (*training)(0)->GetOldLabel();
	unsigned int i;
	for (i=1;i<training->GetSize();++i)
	{
		x0min = MIN(x0min,((*training)(i))->GetFeature_(0));
		x0max = MAX(x0max,((*training)(i))->GetFeature_(0));
		x1min = MIN(x1min,((*training)(i))->GetOldLabel());
		x1max = MAX(x1max,((*training)(i))->GetOldLabel());
	}

	x1min *= scale;
	x1max *= scale;

	x0min-=0.1;	x0max+=0.1;	x1min-=0.1;	x1max+=0.1;

	double x0len,x1len;

	if ((x0max-x0min)>(x1max-x1min))
	{
		x0len = 400;
		x1len = x0len * (x1max-x1min) / (x0max-x0min);
	}else
	{
		x1len = 400;
		x0len = x1len * (x0max-x0min) / (x1max-x1min);
	}

	PSpage pg("regression1d_demo_plot.ps",40,65,100+int(x0len),100+int(x1len));
	PSplot plot1(pg,100.,100.+x0len,100.,100.+x1len);
	plot1.setlimits(x0min,x0max,x1min,x1max);
	plot1.frame();
	//plot1.autoscales();
	plot1.xlabel("x");
	plot1.ylabel("y");

	RVMpoint* pt = new RVMpoint(1);
	bool firstPoint = true;
	double prev_x,prev_y;
	for (double xx=x0min;xx<=x0max;xx+= (x0max-x0min)/x0len)
	{
		pt->GetFeature(0)=xx;
		regressor->predictPoint(pt);
		if (!firstPoint)
		{
			plot1.lineseg(prev_x,prev_y,xx,pt->GetNewLabel()*scale);
		}else
		{
			firstPoint = false;
		}
		prev_x = xx;
		prev_y = pt->GetNewLabel()*scale;
	}

	for (i=0;i<training->GetSize();++i)
	{
		if (((*training)(i))->GetRelevant())
			plot1.square(
				((*training)(i))->GetFeature_(0),
				((*training)(i))->GetOldLabel()*scale,
				8,
				8);

		plot1.pointsymbol(
			((*training)(i))->GetFeature_(0),
			((*training)(i))->GetOldLabel()*scale,
			108,
			7.);
	}

	pg.close();
	pg.display();

	//Release Memory
	delete pt;
	delete regressor;
	delete kernel;

	return 0;
}
