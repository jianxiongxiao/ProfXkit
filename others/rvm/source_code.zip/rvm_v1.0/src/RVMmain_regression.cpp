/* RVM++: Relevance Vector Machine in C++
 *
 * Copyright (C) 2008 XIAO Jianxiong
 *
 * http://www.cse.ust.hk/~csxjx/
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include <iostream>
using namespace std;
#include "RVMregressor.h"
using namespace RVM;

int main(int argc, char** argv)
{
	cout << "Regressor of Relevance Vector Machine in C++ by XIAO Jianxiong @ April 19th, 2008" <<endl;

	if (argc<4)
	{
		cerr <<"Usage: "<< argv[0] <<" Training.file Testing.file Out.file [Kernel=+gauss Width=.5 InitAlpha=(1/N)^2 InitBeta=STD/10 MaxIts=500]"<<endl;

		cerr <<"                                                      "<<endl;
		cerr <<"Kernel Choices:                                       "<<endl;
		cerr <<"    gauss     Gaussian                                "<<endl;
		cerr <<"    laplace   Laplacian                               "<<endl;
		cerr <<"    poly      Polynomial                              "<<endl;
		cerr <<"    hpoly     Homogeneous Polynomial                  "<<endl;
		cerr <<"    cauchy    Cauchy (heavy tailed) in distance       "<<endl;
		cerr <<"    cubic     Cube of distance                        "<<endl;
		cerr <<"    r         Distance                                "<<endl;
		cerr <<"    tps       'Thin-plate' spline                     "<<endl;
		cerr <<"    bubble    Neighbourhood indicator                 "<<endl;
		cerr <<"                                                      "<<endl;
		//cerr <<"    Prefix with + to add bias (e.g. +gauss)           "<<endl;
		cerr <<"                                                      "<<endl;

		return 1;
	}

	RVMdataset* training = new RVMdataset(argv[1]);
	//cerr<<*training;	//Debug
	RVMdataset* testing  = new RVMdataset(argv[2]);

	//Default parameters
	unsigned int maxIts = 500;
	double tmpDouble = 1.0/ double(training->GetSize());
	double initAlpha = tmpDouble * tmpDouble;
	double epsilon= training->OldLabelSTD()/10.0;
	double initBeta = 1.0/ (epsilon * epsilon);
	char kernelname[256]="+gauss";
	double width = 0.5;
	bool withBias = false;

	//Check if user specify the parameters
	if (argc>=5)
	{
		strcpy(kernelname, argv[4]);
	}

	if (kernelname[0]=='+')
	{
		unsigned int i=0;
		while (kernelname[i]!='\0')
		{
			kernelname[i] = kernelname[i+1];
			++i;
		}
		withBias = true;
	}

	if (argc>=6)	width = atof(argv[5]);
	if (argc>=7)	initAlpha = atof(argv[6]);
	if (argc>=8)	initBeta = atof(argv[7]);
	if (argc>=9)	maxIts = atoi(argv[8]);

	//Train the model
	RVMkernel* kernel = new RVMkernel(kernelname,width);
	RVMregressor* regressor = new RVMregressor(training,kernel,maxIts,withBias,initAlpha,initBeta);

	//Train
	regressor->train();

	//Prediction
	regressor->predictDataset(testing);

	//Save the results
	testing->save(argv[3]);

	//Release Memory
	delete regressor;
	delete kernel;

	return 0;
}
