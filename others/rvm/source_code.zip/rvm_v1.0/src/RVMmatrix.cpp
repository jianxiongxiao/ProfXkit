/* RVM++: Relevance Vector Machine in C++
 *
 * Copyright (C) 2008 XIAO Jianxiong
 *
 * http://www.cse.ust.hk/~csxjx/
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include "RVMmatrix.h"
#include "RVMfunc.h"
#include <cmath>
#include <vector>
using namespace std;

namespace RVM
{

	//Member Functions

	RVMmatrix::RVMmatrix()
		: rows(0)
		, cols(0)
		, values(NULL)
	{
	}

	RVMmatrix::RVMmatrix(unsigned int _rows,unsigned int _cols)
		: values(NULL)
	{
		Allocate(_rows,_cols);
	}

	RVMmatrix::RVMmatrix(const RVMmatrix& Matrix)
		: values(NULL)
	{
		Allocate(Matrix.GetRows(),Matrix.GetCols());
		for (unsigned int i=0;i<rows;++i)
		{
			for (unsigned int j=0;j<cols;++j)
			{
				(*this)(i,j) = Matrix._(i,j);
			}
		}
	}

	RVMmatrix::~RVMmatrix() { delete[] values; }

	void RVMmatrix::Allocate(unsigned int _rows,unsigned int _cols)
	{
		if (values!=NULL)	delete [] values;
		rows = _rows;
		cols = _cols;
		values = new double[rows*cols];
	}



	void RVMmatrix::Fill(double Fill_)
	{
		for (unsigned int k=0; k<GetRows()*GetCols(); values[k++]= Fill_);
	}
	
	RVMmatrix RVMmatrix::Transpose_() const
	{
		RVMmatrix Res(GetCols(), GetRows());
		for (unsigned int i=0; i<GetRows(); i++)
			for (unsigned int j=0; j<GetCols(); j++)
				Res(j,i)= this->_(i,j);
		//cerr<<Res;
		return Res;
	}

	void RVMmatrix::Transpose()
	{
		double* Aux= new double[GetRows()*GetCols()];
		for (unsigned int i=0; i< GetRows(); i++)
			for (unsigned int j=0; j< GetCols(); j++)
				Aux[j*GetRows()+i]= this->_(i,j);
		unsigned int tmp = rows;
		rows = cols;
		cols = tmp;
		delete[] values;
		values= Aux; 
	}
	
	const RVMmatrix& RVMmatrix::operator=(const RVMmatrix& Matrix)
	{
		if (GetRows()!= Matrix.GetRows() || GetCols()!= Matrix.GetCols()) 
			Allocate(Matrix.GetRows(),Matrix.GetCols());
		for (unsigned int k=0; k<GetRows()*GetCols(); k++)
			values[k]= Matrix.values[k];
		return *this;
	}

	const RVMmatrix& RVMmatrix::operator+=(const RVMmatrix& Matrix)
	{
		if (GetRows()!= Matrix.GetRows() || GetCols()!= Matrix.GetCols())
		{
			cerr<<"Fatal Error: Matrix Size Not Matched in RVMmatrix::operator+= "<<endl;
			exit(1);
		}
		for (unsigned int i=0; i< GetRows(); i++)
			for (unsigned int j=0; j< GetCols(); j++)
				(*this)(i,j)+= Matrix._(i,j); 
		return *this;
	}

	const RVMmatrix& RVMmatrix::operator-=(const RVMmatrix& Matrix)
	{
		if (GetRows()!= Matrix.GetRows() || GetCols()!= Matrix.GetCols())
		{
			cerr<<"Fatal Error: Matrix Size Not Matched in RVMmatrix::operator-= "<<endl;
			exit(1);
		}
		for (unsigned int i=0; i< GetRows(); i++)
			for (unsigned int j=0; j< GetCols(); j++)
				(*this)(i,j)-= Matrix._(i,j); 
		return *this;
	}

	const RVMmatrix& RVMmatrix::operator*=(double scalar)
	{
		for (unsigned int i=0; i< GetRows(); i++)
			for (unsigned int j=0; j< GetCols(); j++)
				(*this)(i,j)*= scalar;
		return *this;
	}

	const RVMmatrix& RVMmatrix::operator/=(double scalar)
	{
		if (scalar==0)
		{
			cerr<<"Fatal Error: Divided by Zero in RVMmatrix::operator/= "<<endl;
			exit(1);
		}else
		{
			(*this)*= 1/scalar;
		}
		return *this;
	}

	//Non-member functions

	RVMmatrix operator+(const RVMmatrix& Matrix0, const RVMmatrix& Matrix1)
	{
		if (Matrix0.GetRows()!= Matrix1.GetRows() || Matrix0.GetCols()!= Matrix1.GetCols())
		{
			cerr<<"Fatal Error: Matrix Size Not Matched in operator+ "<<endl;
			exit(1);
		}
		RVMmatrix Res(Matrix0.GetRows(), Matrix0.GetCols());
		for (unsigned int i=0; i< Res.GetRows(); i++)
			for (unsigned int j=0; j< Res.GetCols(); j++)
				Res(i,j)= Matrix0._(i,j)+Matrix1._(i,j);
		return Res;
	}

	RVMmatrix operator-(const RVMmatrix& Matrix0, const RVMmatrix& Matrix1)
	{
		if (Matrix0.GetRows()!= Matrix1.GetRows() || Matrix0.GetCols()!= Matrix1.GetCols())
		{
			cerr<<"Fatal Error: Matrix Size Not Matched in operator- "<<endl;
			exit(1);
		}
		RVMmatrix Res(Matrix0.GetRows(), Matrix0.GetCols());
		for (unsigned int i=0; i< Res.GetRows(); i++)
			for (unsigned int j=0; j< Res.GetCols(); j++)
				Res(i,j)= Matrix0._(i,j)-Matrix1._(i,j);
		return Res;
	}

	RVMmatrix operator*(const RVMmatrix& Matrix0, const RVMmatrix& Matrix1)
	{
		if (Matrix0.GetCols()!= Matrix1.GetRows())
		{
			cerr<<"Fatal Error: Matrix Size Not Matched in operator* "<<endl;
			exit(1);
		}
		RVMmatrix Res(Matrix0.GetRows(), Matrix1.GetCols());
		for (unsigned int i=0; i< Res.GetRows(); i++)
			for (unsigned int j=0; j< Res.GetCols(); j++)
			{
				Res(i,j) = 0.0;
				for (unsigned int k=0; k< Matrix0.GetCols(); k++)
					Res(i,j)+= Matrix0._(i,k)*Matrix1._(k,j);
			}
		return Res;
	}

	RVMmatrix operator*(double a, const RVMmatrix& Matrix)
	{
		RVMmatrix Res(Matrix.GetRows(), Matrix.GetCols());
		for (unsigned int i=0; i< Res.GetRows(); i++)
			for (unsigned int j=0; j< Res.GetCols(); j++)
				Res(i,j)= a*Matrix._(i,j);
		return Res;
	}

	RVMmatrix operator*(const RVMmatrix& Matrix, double a)
	{
		return a*Matrix;
	}

	RVMmatrix operator/(const RVMmatrix& Matrix, double a)
	{
		if (a==0)
		{
			cerr<<"Fatal Error: Divided by Zero in operator/ "<<endl;
			exit(1);
		}
		return (1/a)*Matrix;
	}

	ostream& operator<<(ostream& Out, const RVMmatrix& Matrix)
	{
		Out << "Rows=" << Matrix.GetRows() << " Cols=" << Matrix.GetCols() << endl;
		//if (Matrix.GetCols()==1)
		//{
		//	for (unsigned int i=0; i<Matrix.GetRows(); i++)
		//	{
		//		Out << Matrix._(i,0) << " ";
		//	}
		//	Out << endl;
		//} else
		{
			for (unsigned int i=0; i<Matrix.GetRows(); i++)
			{
				for (unsigned int j=0; j<Matrix.GetCols(); j++)
				{
					Out << Matrix._(i,j) << " ";
				}
				Out << endl;
			}
		}
		return Out;
	}

	// For vectors
	double Dot(const RVMmatrix& Matrix0, const RVMmatrix& Matrix1)
	{
		if (Matrix0.GetCols()!= Matrix1.GetCols() || !Matrix0.IsVector() || !Matrix1.IsVector())
		{
			cerr<<"Fatal Error: Dot product between two non-equal length vector in Dot"<<endl;
			exit(1);
		}
		double Res=0;
		for (unsigned int i=0; i<Matrix0.GetRows(); i++)
			Res+=Matrix0._(i)*Matrix1._(i);
		return Res;
	}

	RVMmatrix diag(const RVMmatrix& Matrix)
	{
		if (!Matrix.IsVector())
		{
			cerr<<"Fatal Error: Input Matrix is Non-vector in diag"<<endl;
			exit(1);
		}
		RVMmatrix Res(Matrix.GetRows(), Matrix.GetRows());
		Res.Fill(0);
		for (unsigned int i=0; i< Res.GetRows(); ++i)
			Res(i,i)= Matrix._(i,0);
		return Res;
	}

	RVMmatrix Mlog(const RVMmatrix& Matrix)
	{
		RVMmatrix Res(Matrix.GetRows(), Matrix.GetCols());
		for (unsigned int i=0; i< Matrix.GetRows(); ++i)
			for (unsigned int j=0; j< Matrix.GetCols(); ++j)
				Res(i,j)= log(Matrix._(i,j));
		return Res;
	}

	RVMmatrix sum(const RVMmatrix& Matrix,unsigned char Dim)
	{
		if (Matrix.IsVector())	Dim = 1;
		if (Dim==1)
		{
			RVMmatrix result(1,Matrix.GetCols());
			for (unsigned int i=0;i<Matrix.GetCols();++i)
			{
				result(0,i) = 0.0;
				for(unsigned int j=0;j<Matrix.GetRows();++j)
					result(0,i) += Matrix._(j,i);
			}
			return result;
		}else
		{
			RVMmatrix result(Matrix.GetRows(),1);
			for (unsigned int i=0;i<Matrix.GetRows();++i)
			{
				result(i,0) = 0.0;
				for(unsigned int j=0;j<Matrix.GetCols();++j)
					result(i,0) += Matrix._(i,j);
			}
			return result;
		}
	}
	
	RVMmatrix Mpow(const RVMmatrix& Matrix, double exponent)
	{
		RVMmatrix Res(Matrix.GetRows(), Matrix.GetCols());
		for (unsigned int i=0; i< Matrix.GetRows(); ++i)
			for (unsigned int j=0; j< Matrix.GetCols(); ++j)
				Res(i,j)= pow(Matrix._(i,j),exponent);
		return Res;
	}

	RVMmatrix sigmoid(const RVMmatrix& Matrix)
	{
		RVMmatrix Res(Matrix.GetRows(), Matrix.GetCols());
		for (unsigned int i=0; i< Matrix.GetRows(); ++i)
			for (unsigned int j=0; j< Matrix.GetCols(); ++j)
				Res(i,j)= sigmoid(Matrix._(i,j));
		return Res;
	}

	// Linear equation solution by Gauss-Jordan elimination
	// Modified based on NUMERICAL RECIPES: The Art of Scientific Computing (3rd Edition)
	// The input matrix is a[0..n-1][0..n-1].
	// b[0..n-1][0..m-1] is input containing the m right-hand side vectors.
	// On output, a is replaced by its matrix inverse, 
	// and b is replaced by the corresponding set of solution vectors.
	void gaussj(RVMmatrix &a, RVMmatrix &b)
	{
		int i,icol,irow,j,k,l,ll,n=a.GetRows(),m=b.GetCols();
		double big,dum,pivinv;
		vector<int> indxc(n),indxr(n),ipiv(n);
		for (j=0;j<n;j++) ipiv[j]=0;
		for (i=0;i<n;i++)
		{
			big=0.0;
			for (j=0;j<n;j++)
				if (ipiv[j] != 1)
					for (k=0;k<n;k++)
					{
						if (ipiv[k] == 0)
						{
							if (abs(a._(j,k)) >= big)
							{
								big=abs(a._(j,k));
								irow=j;
								icol=k;
							}
						}
					}
					++(ipiv[icol]);
					if (irow != icol)
					{
						for (l=0;l<n;l++) SWAP(a(irow,l),a(icol,l));
						for (l=0;l<m;l++) SWAP(b(irow,l),b(icol,l));
					}
					indxr[i]=irow;
					indxc[i]=icol;
					if (a._(icol,icol) == 0.0)
					{
						cerr<< "Fatal Error: Singular Matrix in gaussj"<<endl;
						exit(0);
					}
					pivinv=1.0/a._(icol,icol);
					a(icol,icol)=1.0;
					for (l=0;l<n;l++) a(icol,l) *= pivinv;
					for (l=0;l<m;l++) b(icol,l) *= pivinv;
					for (ll=0;ll<n;ll++)
						if (ll != icol)
						{
							dum=a._(ll,icol);
							a(ll,icol)=0.0;
							for (l=0;l<n;l++) a(ll,l) -= a._(icol,l)*dum;
							for (l=0;l<m;l++) b(ll,l) -= b._(icol,l)*dum;
						}
		}
		for (l=n-1;l>=0;l--)
		{
			if (indxr[l] != indxc[l])
				for (k=0;k<n;k++)
					SWAP(a(k,indxr[l]),a(k,indxc[l]));
		}
	}
	
	// Overloaded version with no right-hand sides. Replaces a by its inverse
	void gaussj(RVMmatrix &a)
	{
		RVMmatrix b(a.GetRows(),0);	//Dummy vector with zero columns
		gaussj(a,b);
	}

	//Given a positive-definite symmetric matrix, get its Cholesky decomposition  A=L*L'
	//Modified based on NUMERICAL RECIPES: The Art of Scientific Computing (3rd Edition)
	void cholesky(RVMmatrix &Matrix)
	{
		if (!Matrix.IsSquareMatrix())
		{
			cerr<<"Fatal Error: Cholesky decomposition only support square matrix in cholesky."<<endl;
			exit(1);
		}
		int n = int(Matrix.GetRows());
		int i,j,k;
		vector<double> tmp;
		double sum;
		for (i=0;i<n;++i)
		{
			for (j=i;j<n;++j)
			{
				sum=Matrix(i,j);
				if (i>=1)
				{
					for (k=i-1;k>=0;k--)
						sum -= Matrix._(i,k)*Matrix._(j,k);
				}
				if (i == j)
				{
					if (sum <= 0.0)
					{
						cerr<<"Fatal Error: With rounding errors, the matrix is not positive-definite. Cholesky failed in cholesky."<<endl;
						exit(1);
					}
					Matrix(i,i)=sqrt(sum);
				}else
				{
					Matrix(j,i)=sum/Matrix._(i,i);
				}
			}
		}
		for (i=0;i<n;++i) 
			for (j=0;j<i;++j) 
				Matrix(j,i) = 0.0;
	}


	// Assume X is positive definite, then U = chol(X) produces an upper triangular U so that U'*U = X
    void chol(const RVMmatrix& Matrix, RVMmatrix& U)
	{
		U = Matrix;
		cholesky(U);
		U.Transpose();
		
		return;

		//////////////////////////////////////////////////////////////////////////
		if (!Matrix.IsSquareMatrix())
		{
			cerr<<"Fatal Error: Cholesky decomposition only support square matrix in chol."<<endl;
			exit(1);
		}
		
		unsigned int N = Matrix.GetRows();

		if (!U.IsSquareMatrix() || U.GetRows()!= Matrix.GetRows())
		{
			U.Allocate(N,N);
		}

		unsigned int j, k;
			
		for (unsigned int row=0; row<N; ++row)
		{
			// First compute U(row,row)
			double sum = Matrix._(row,row);
			for (j=0; j<row-1; ++j)
				sum -= U._(j,row)*U._(j,row);
			if (sum > 1.0e-9)
			{
				U(row,row) = sqrt(sum);
				// Now find elements U(row,k), k > row
				for (k=row+1; k<N; ++k)
				{
					sum = Matrix._(row,k);
					for (j=0; j<row-1; j++) 
						sum -= U._(j,row)*U._(j,k);
					U(row,k) = sum / U._(row,row);
				}
			}
			else
			{	// blast off the entire row
				for (k=row; k<=N; k++)
					U(row,k) = 0.0;
			}
		}

	}
}

