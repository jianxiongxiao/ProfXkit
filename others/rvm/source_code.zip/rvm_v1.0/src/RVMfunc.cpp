/* RVM++: Relevance Vector Machine in C++
 *
 * Copyright (C) 2008 XIAO Jianxiong
 *
 * http://www.cse.ust.hk/~csxjx/
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include "RVMfunc.h"
#include <cmath>
using namespace std;

namespace RVM
{
	double sigmoid	(double x)
	{
		return 1.0/(1+exp(-x));
	}
	double sclSqrDis(const RVMpoint* Point0, const RVMpoint* Point1, double lenscal)
	{
		if (Point0->GetDimension()!=Point1->GetDimension())
		{
			cerr<<"Fatal Error: The square distance function only support equal length vector in sclSqrDis"<<endl;
			exit(1);
		}
		double result=0.0;
		for (unsigned int i=0;i<Point0->GetDimension();++i)
		{
			double tmpDouble = Point0->GetFeature_(i) - Point1->GetFeature_(i);
			result += tmpDouble*tmpDouble;
		}
		double eta	= 1.0/(lenscal*lenscal);
		return eta*result;
	}
	
	//Gaussian
	double Kgauss	(const RVMpoint* Point0, const RVMpoint* Point1, double lenscal)
	{
		return exp(-sclSqrDis(Point0,Point1,lenscal));
	}

	//Laplacian
	double Klaplace	(const RVMpoint* Point0, const RVMpoint* Point1, double lenscal)
	{
		return exp(-sqrt(sclSqrDis(Point0,Point1,lenscal)));
	}

	//Cauchy (heavy tailed) in distance
	double Kcauchy	(const RVMpoint* Point0, const RVMpoint* Point1, double lenscal)
	{
		double r2 = sclSqrDis(Point0,Point1,lenscal);
		return 1.0/(1.0+r2);
	}

	//Cube of distance
	double Kcubic	(const RVMpoint* Point0, const RVMpoint* Point1, double lenscal)
	{
		double r2 = sclSqrDis(Point0,Point1,lenscal);
		return r2 * sqrt(r2);
	}

	//Distance
	double Kr		(const RVMpoint* Point0, const RVMpoint* Point1, double lenscal)
	{
		double r2 = sclSqrDis(Point0,Point1,lenscal);
		return sqrt(r2);
	}

	//'Thin-plate' spline
	double Ktps		(const RVMpoint* Point0, const RVMpoint* Point1, double lenscal)
	{
		double r2 = sclSqrDis(Point0,Point1,lenscal);
		return 0.5 * r2 * log(r2 + double(r2==0));
	}

	//Neighbourhood indicator
	double Kbubble	(const RVMpoint* Point0, const RVMpoint* Point1, double lenscal)
	{
		double r2 = sclSqrDis(Point0,Point1,lenscal);
		if (r2<1)
			return 1.0;
		else
			return 0.0;
	}

	//Polynomial
	double Kpoly		(const RVMpoint* Point0, const RVMpoint* Point1, double lenscal)
	{

		return Khpoly(Point0,Point1,lenscal)+1.0;
	}
	
	//Homogeneous Polynomial
	double Khpoly	(const RVMpoint* Point0, const RVMpoint* Point1, double lenscal)
	{
		double eta	= 1.0/(lenscal*lenscal);
		double result=0;
		for (unsigned int i=0;i<Point0->GetDimension();++i)
		{
			result += Point0->GetFeature_(i) * Point1->GetFeature_(i);
		}
		result *= eta;
		return result;
	}

}
