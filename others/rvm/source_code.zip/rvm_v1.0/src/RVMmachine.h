/* RVM++: Relevance Vector Machine in C++
 *
 * Copyright (C) 2008 XIAO Jianxiong
 *
 * http://www.cse.ust.hk/~csxjx/
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#ifndef RVMMACHINE_H
#define RVMMACHINE_H

#include "RVMmatrix.h"
#include "RVMdataset.h"
#include "RVMkernel.h"

namespace RVM
{
	class RVMmachine
	{
	public:
		RVMmachine();
		RVMmachine(RVMdataset* _training,RVMkernel* _kernel,
			unsigned int _maxIts,bool _withBias,double _initAlpha,double _initBeta=0.0);
		void predictDataset(RVMdataset* dataset);
		virtual void predictPoint(RVMpoint* curPt);

		RVMdataset* GetTraining	();
		RVMkernel* GetKernel	();
		unsigned int GetMaxIts	();
		double GetInitAlpha		();
		double GetInitBeta		();
		bool GetWithBias		();

		void SetTraining		(RVMdataset* _training);
		void SetKernel			(RVMkernel* _kernel);
		void SetMaxIts			(unsigned int _maxIts);
		void SetInitAlpha		(double _initAlpha);
		void SetInitBeta		(double _initBeta);
		void SetWithBias		(bool _withBias);

		void train();

		virtual void estimate(RVMmatrix const & PHI,RVMmatrix const & t, RVMmatrix const & alpha, RVMmatrix & w, RVMmatrix & Ui, double & betaED, double & logBeta, double beta, unsigned int ptNum,double& ED) = 0;

	private:

		void ComputeRelevantVector();
		RVMdataset* training;
		vector<RVMpoint*> relevantVectors;
		RVMkernel* kernel;
		bool withBias;
		double bias;
		unsigned int maxIts;
		double initAlpha;
		double initBeta;
		double beta;
	};
}

#endif
