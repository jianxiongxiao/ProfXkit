/* RVM++: Relevance Vector Machine in C++
 *
 * Copyright (C) 2008 XIAO Jianxiong
 *
 * http://www.cse.ust.hk/~csxjx/
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#ifndef RVMKERNEL_H
#define RVMKERNEL_H

#include "RVMfunc.h"

namespace RVM
{
	class RVMkernel
	{
	public:
		RVMkernel();
		RVMkernel(char* _name,double _lenscal);
		~RVMkernel();
		double evaluate(const RVMpoint* Point0, const RVMpoint* Point1);
	private:
		char name[256];
		double lenscal;
		double exponent;
		double (*func)(const RVMpoint*, const RVMpoint*, double);
	};
}

#endif
