/* RVM++: Relevance Vector Machine in C++
 *
 * Copyright (C) 2008 XIAO Jianxiong
 *
 * http://www.cse.ust.hk/~csxjx/
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include "RVMkernel.h"
#include <stdlib.h>
#include <cmath>
using namespace std;

namespace RVM
{
	RVMkernel::RVMkernel()
		: func(NULL)
		, exponent(1.0)
	{
		strcpy(name,"NONE");
	}

	RVMkernel::RVMkernel(char* _name,double _lenscal)
		: lenscal(_lenscal)
		, func(NULL)
		, exponent(1.0)
	{
		char polyname[6];
		unsigned int i;
		for (i=0;i<4;i++)
		{
			polyname[i]= _name[i];
		}
		polyname[i]='\0';

		if (0==strcmp(polyname,"poly"))
		{
			exponent = atof(_name+4);
			_name[4]='\0';
		}else if (0==strcmp(polyname,"hpol"))
		{
			exponent = atof(_name+5);
			_name[5]='\0';
		}

		strcpy(name,_name);
		if (0==strcmp(name,"gauss"))
			func = & Kgauss;
		else if (0==strcmp(name,"laplace"))
			func = & Klaplace;
		else if (0==strcmp(name,"poly"))
			func = & Kpoly;
		else if (0==strcmp(name,"hpoly"))
			func = & Khpoly;
		else if (0==strcmp(name,"cauchy"))
			func = & Kcauchy;
		else if (0==strcmp(name,"cubic"))
			func = & Kcubic;
		else if (0==strcmp(name,"r"))
			func = & Kr;
		else if (0==strcmp(name,"tps"))
			func = & Ktps;
		else if (0==strcmp(name,"bubble"))
			func = & Kbubble;
		else
		{
			cerr<<"Fatal Error: Unrecognized Kernel Function"<<endl;
			exit(1);
		}
	}

	RVMkernel::~RVMkernel()
	{
	}

	double RVMkernel::evaluate(const RVMpoint* Point0, const RVMpoint* Point1)
	{
		double result = (*func)(Point0,Point1,lenscal);
		if (exponent!=1.0)
			result = pow(result,exponent);
		return result;
	}

}
