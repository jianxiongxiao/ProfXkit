/* RVM++: Relevance Vector Machine in C++
 *
 * Copyright (C) 2008 XIAO Jianxiong
 *
 * http://www.cse.ust.hk/~csxjx/
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#ifndef RVMCONSTANT_H
#define RVMCONSTANT_H

namespace RVM
{
	// Terminate estimation when no log-alpha value changes by more than this
	const double MIN_DELTA_LOGALPHA = 1e-6;//1e-3;

	// Prune basis function when its alpha is greater than this
	const double ALPHA_MAX = 1e12;

	// Iteration number during training where we switch to 'analytic pruning'
	const double PRUNE_POINT = 0.5;

	// Classification settings
	const unsigned int PM_MAXITS = 25;	// Posterior mode-finder
	const double STOP_CRITERION = 1e-6;
	const double LAMBDA_MIN = 0.00390625;	//2^(-8);

	// Regression settings
	const bool FIXED_BETA = false;
}

#endif
