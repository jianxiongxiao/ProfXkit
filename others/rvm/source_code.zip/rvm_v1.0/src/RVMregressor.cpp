/* RVM++: Relevance Vector Machine in C++
 *
 * Copyright (C) 2008 XIAO Jianxiong
 *
 * http://www.cse.ust.hk/~csxjx/
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include "RVMregressor.h"
#include "RVMmatrix.h"
#include <cmath>
using namespace std;
namespace RVM
{
	RVMregressor::RVMregressor():RVMmachine()
	{
	}

	RVMregressor::RVMregressor(RVMdataset* _training, RVMkernel* _kernel,
		unsigned int _maxIts, bool _withBias, double _initAlpha,double _initBeta)
		:RVMmachine(_training,_kernel,_maxIts,_withBias,_initAlpha,_initBeta)
	{
	}

	void RVMregressor::estimate(RVMmatrix const & PHI,RVMmatrix const & t, RVMmatrix const & alpha, RVMmatrix & w, RVMmatrix & Ui, double & betaED, double & logBeta, double beta, unsigned int ptNum,double& ED)
	{
		unsigned int d = PHI.GetCols();
		RVMmatrix Hessian( ( PHI.Transpose_() * PHI ) * beta + diag(alpha));
		RVMmatrix U(d,d);		// Cholesky factorization: U'*U = Hessian
		chol(Hessian,Ui);
		gaussj(Ui);
		w = (Ui * (Ui.Transpose_()* (PHI.Transpose_() * t) ))* beta;
		ED = sum( Mpow(t-PHI*w,2) )(0,0);
		betaED = beta*ED;
		logBeta = ptNum * log(beta);
	}
}
