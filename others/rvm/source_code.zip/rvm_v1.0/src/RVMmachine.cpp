/* RVM++: Relevance Vector Machine in C++
 *
 * Copyright (C) 2008 XIAO Jianxiong
 *
 * http://www.cse.ust.hk/~csxjx/
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include "RVMmatrix.h"
#include "RVMmachine.h"
#include "RVMconstant.h"
#include <cmath>
using namespace std;

namespace RVM
{
	RVMmachine::RVMmachine()
		: training(NULL)
		, kernel(NULL)
	{
	}

	RVMmachine::RVMmachine(RVMdataset* _training,RVMkernel* _kernel,
		unsigned int _maxIts,bool _withBias,double _initAlpha,double _initBeta)
		: training(_training)
		, kernel(_kernel)
		, maxIts(_maxIts)
		, withBias(_withBias)
		, initAlpha(_initAlpha)
		, initBeta(_initBeta)
	{
	}

	void RVMmachine::predictDataset(RVMdataset* dataset)
	{
		if (training==NULL || kernel==NULL)
		{
			cerr<<"Fatal Error: Using a un-trained model to predict in RVMmachine::predict"<<endl;
			exit(1);
		}
		//For speed up
		if (relevantVectors.size()==0)
		{
			ComputeRelevantVector();
		}
		for (unsigned int i=0;i<dataset->GetSize();++i)
		{
			RVMpoint* curPt = ((*dataset)(i));
			predictPoint(curPt);
		}
	}

	void RVMmachine::predictPoint(RVMpoint* curPt)
	{
		int numRelevantVectors = relevantVectors.size();
		double new_label = 0.0;
		for (int j=0;j<numRelevantVectors;j++)
		{
			RVMpoint* curVec =  relevantVectors[j];
			new_label += curVec->GetW() * kernel->evaluate(curPt,curVec);
		}
		if (withBias)
			new_label += bias;
		curPt->SetNewLabel(new_label);
	}

	void RVMmachine::ComputeRelevantVector()
	{
		relevantVectors.clear();
		for (unsigned int i=0;i<training->GetSize();++i)
		{
			if (((*training)(i))->GetRelevant())
			{
				relevantVectors.push_back((*training)(i));
			}
		}
	}

	void RVMmachine::train()
	{
		beta = initBeta;

		unsigned int i,j,k;
		unsigned int N = training->GetSize();
		unsigned int M ;
		RVMmatrix* PHI;
		if (withBias)
		{
			M = N+1;
			PHI = new RVMmatrix(N,M);
			for (i=0;i<N;++i)
			{
				(*PHI)(i,0) = 1.0;
				for (j=i;j<N;++j)
				{
					(*PHI)(i,j+1) = (*PHI)(j,i+1) = kernel->evaluate((*training)(i),(*training)(j));
				}
			}
		}else
		{
			M = N;
			PHI = new RVMmatrix(N,M);
			for (i=0;i<N;i++)
				for (j=i;j<N;j++)
					(*PHI)(i,j) = (*PHI)(j,i) = kernel->evaluate((*training)(i),(*training)(j));
		}
		RVMmatrix t(N,1);
		for (i=0;i<N;++i)	t(i)= (*training)(i)->GetOldLabel();
		RVMmatrix PHIt( PHI->Transpose_() * t );

		RVMmatrix w(M,1);		w.Fill(0);
		RVMmatrix alpha(M,1);	alpha.Fill(initAlpha);
		RVMmatrix gamma(M,1);	gamma.Fill(1.0);
		bool* nonZero= new bool[M];	memset((void*)nonZero,true,M*sizeof(bool));
		unsigned int numBases = M;
		bool isLastIt = false;
		unsigned int prune_it = (unsigned int)(PRUNE_POINT * maxIts);
		for (i=0;i<maxIts;++i)
		{
			cerr<<"The "<<i+1<<"-th iteration is running: ";

			// Prune large values of alpha
				M = 0;
				for (j=0;j<numBases;++j)
					if(nonZero[j])
					{
						if (alpha(j)>=ALPHA_MAX)
						{
							nonZero[j]=false;
							++M;
						}
					}else
					{
						++M;
					}
				M = numBases - M;

				cerr<<"# of relevant vectors = "<<M<<endl;

			// Work with non-pruned basis
				RVMmatrix w_nz(M,1);
				RVMmatrix alpha_nz(M,1);
				RVMmatrix PHI_nz(N,M);
				M = 0;
				for (j=0;j<numBases;++j)
				{
					if (nonZero[j])
					{
						w_nz(M) = w(j);
						alpha_nz(M) = alpha(j);
						for(k=0;k<N;++k)
							PHI_nz(k,M) = (*PHI)(k,j);
						++M;
					}
				}
			// Hyper-parameters Estimation
				RVMmatrix Ui(M,M);

				double betaED,ED;
				double logBeta;
				estimate(PHI_nz,t,alpha_nz,w_nz,Ui,betaED,logBeta,beta,N,ED);

				M = 0;
				for (j=0;j<numBases;++j)
				{
					if (nonZero[j])
					{
						w(j) = w_nz(M);
						++M;
					}
				}

				//cerr<<w_nz;
				//cerr<<Ui;

			// Quick ways to get determinant and diagonal of posterior weight covariance matrix 'SIGMA'
			// de-comment the following lines for computation of marginal likelihood
			//	double logdetH = 0.0;
			//	for (j=0;j<M;++j)	logdetH += log( Ui(j,j) );
			//	logdetH *= -2.0;

			// Well-determinedness parameters
				RVMmatrix gamma(M,1);
				RVMmatrix diagSig(M,1);
				for (j=0;j<M;++j)
				{
					double diagSigJ = 0.0;
					for (k=0;k<M;++k)	diagSigJ += pow(Ui(j,k),2);
					diagSig(j) = diagSigJ;
					gamma(j)= 1- alpha_nz(j)*diagSigJ;
				}

			// Compute marginal likelihood ln p(t|X,alpha,beta) (approximation for classification case)
			// de-comment the following lines for computation of marginal likelihood
			// double marginal = -0.5* (logdetH - sum(Mlog(alpha_nz))(0,0) - logBeta + betaED + Dot(Mpow(w_nz,2),alpha_nz));
			// cout<< "marginal likelihood ln p(t|X,alpha,beta) = " << marginal <<endl;

			// alpha and beta re-estimation on all but last iteration
			// (we just update the posterior statistics the last time around)
				if (!isLastIt)
				{
					double maxDAlpha = 0.0;
					M=0;
					for (j=0;j<numBases;++j)
					{
						if (nonZero[j])
						{
							double wM = w_nz(M);
							double old_alphaJ = alpha(j);
							if (i<prune_it)
							{	// MacKay-style update given in original NIPS paper
								alpha(j) = gamma(M) / (wM*wM);
							}else
							{	// Hybrid update based on NIPS theory paper and AISTATS
								double gammaM = gamma(M);
								double alphaJ = gammaM / (wM*wM/gammaM-diagSig(M));
								if (alphaJ<=0)
								{
									alphaJ = ALPHA_MAX+1;	//This will be pruned
								}
								alpha(j) = alphaJ;
							}
							double deltaLogAlpha = fabs(log(old_alphaJ)-log(alpha(j)));
							if (deltaLogAlpha>maxDAlpha)	maxDAlpha = deltaLogAlpha;
							++M;
						}
					}

					if (maxDAlpha<MIN_DELTA_LOGALPHA)
					{
						isLastIt = true;
					}

					//Beta re-estimate in regression (unless fixed)
					if (!FIXED_BETA)
					{
						beta = (N - sum(gamma)(0,0))/ED;
					}
				}else
				{
					break;
				}
		}

		// Tidy up return values
		if (withBias)	M=1;
		else			M=0;

		for (j=0;j<training->GetSize();++j)
		{
			((*training)(j))->SetRelevant(nonZero[M]);
			if (nonZero[M])
				((*training)(j))->SetW(w(M));
			M++;
		}

		withBias = nonZero[0];
		if (withBias)	bias = w(0);


		delete PHI;
		delete [] nonZero;
		ComputeRelevantVector();
	}

	RVMdataset* RVMmachine::GetTraining()
	{
		return training;
	}

	RVMkernel* RVMmachine::GetKernel()
	{
		return kernel;
	}

	unsigned int RVMmachine::GetMaxIts()
	{
		return maxIts;
	}

	double RVMmachine::GetInitAlpha()
	{
		return initAlpha;
	}

	double RVMmachine::GetInitBeta()
	{
		return initBeta;
	}

	void RVMmachine::SetTraining(RVMdataset* _training)
	{
		training = _training;
	}

	void RVMmachine::SetKernel(RVMkernel* _kernel)
	{
		kernel = _kernel;
	}

	void RVMmachine::SetMaxIts(unsigned int _maxIts)
	{
		maxIts = _maxIts;
	}

	void RVMmachine::SetInitAlpha(double _initAlpha)
	{
		initAlpha = _initAlpha;
	}

	void RVMmachine::SetInitBeta(double _initBeta)
	{
		initBeta = _initBeta;
	}

	bool RVMmachine::GetWithBias()
	{
		return withBias;
	}

	void RVMmachine::SetWithBias(bool _withBias)
	{
		withBias = _withBias;
	}
}
