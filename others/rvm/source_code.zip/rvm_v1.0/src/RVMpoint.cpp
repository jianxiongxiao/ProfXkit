/* RVM++: Relevance Vector Machine in C++
 *
 * Copyright (C) 2008 XIAO Jianxiong
 *
 * http://www.cse.ust.hk/~csxjx/
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include "RVMpoint.h"

namespace RVM
{

	RVMpoint::RVMpoint()
		: feature(NULL)
		, dimension(0)
		, isRelevant(true)
	{
	}

	RVMpoint::RVMpoint(unsigned int _dimension)
		: feature(NULL)
		, dimension (_dimension)
		, isRelevant(true)
	{
		Allocate();
	}
	
	RVMpoint::~RVMpoint()
	{
		if (feature!=NULL)
			delete [] feature;
	}
	
	void RVMpoint::Allocate()
	{
		if (feature !=NULL)
			delete [] feature;
		feature = new double[dimension];
	}

	double* RVMpoint::GetFeature() const
	{
		return feature;
	}

	double&	RVMpoint::GetFeature(unsigned int index)
	{
		if (index>=dimension)
		{
			cerr<<"Fatal Error: Index Out of Range in RVMpoint::GetFeature"<<endl;
			exit(1);
		}
		return feature[index];
	}

	double RVMpoint::GetFeature_(unsigned int index) const
	{
		if (index>=dimension)
		{
			cerr<<"Fatal Error: Index Out of Range in RVMpoint::GetFeature"<<endl;
			exit(1);
		}
		return feature[index];
	}

	bool RVMpoint::GetRelevant() const
	{
		return isRelevant;
	}

	void RVMpoint::SetRelevant(bool new_isRelevant)
	{
		isRelevant = new_isRelevant;
	}
	
	double RVMpoint::GetW() const
	{
		return w;
	}

	void RVMpoint::SetW(double new_w)
	{
		w = new_w;
	}

	double RVMpoint::GetOldLabel() const
	{
		return old_label;
	}

	void RVMpoint::SetOldLabel(double _label)
	{
		old_label = _label;
	}
	
	double RVMpoint::GetNewLabel() const
	{
		return new_label;
	}
	
	void RVMpoint::SetNewLabel(double _label)
	{
		new_label = _label;
	}
	
	unsigned int RVMpoint::GetDimension() const
	{
		return dimension;
	}

	void RVMpoint::SetDimension(unsigned int new_dimension)
	{
		dimension = new_dimension;
	}

	ostream& operator<<(ostream& Out, const RVMpoint& Point)
	{
		Out<<Point.GetNewLabel()<<"\t";
		Out<<Point.GetDimension()<<"\t";
		for (unsigned int i=0;i<Point.GetDimension();++i)
		{
			Out<< Point.GetFeature_(i) <<"\t";
		}
		Out<<endl;
		return Out;
	}

	istream& operator>>(istream& In , RVMpoint& Point)
	{
		double tmpDouble;		In >> tmpDouble;		Point.SetOldLabel(tmpDouble);
		unsigned int tmpUnsignedInt;	In >> tmpUnsignedInt;	Point.SetDimension(tmpUnsignedInt);
		Point.Allocate();
		for (unsigned int i=0;i<tmpUnsignedInt;++i)
		{
			In >> Point.GetFeature(i);
		}
		return In;
	}
}
