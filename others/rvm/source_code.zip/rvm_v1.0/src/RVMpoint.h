/* RVM++: Relevance Vector Machine in C++
 *
 * Copyright (C) 2008 XIAO Jianxiong
 *
 * http://www.cse.ust.hk/~csxjx/
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#ifndef RVMPOINT_H
#define RVMPOINT_H

#include <iostream>
using namespace std;

namespace RVM
{
	class RVMpoint
	{
	public:
		RVMpoint();
		RVMpoint(unsigned int _dimension);
		~RVMpoint();

		void Allocate();
		
		double* GetFeature() const;
		double&	GetFeature(unsigned int index);
		double	GetFeature_(unsigned int index) const;

		bool	GetRelevant() const;
		void	SetRelevant(bool new_isRelevant);

		double	GetW() const;
		void	SetW(double new_w);

		double  GetOldLabel() const;
		void	SetOldLabel(double _label);
		double  GetNewLabel() const;
		void	SetNewLabel(double _label);
		
		unsigned int GetDimension() const;
		void	SetDimension(unsigned int new_dimension);

	private:
		bool	isRelevant;
		double  w;
		double* feature;
		unsigned int dimension;
		double  old_label;
		double  new_label;
	};

	ostream& operator<<(ostream& Out, const RVMpoint& Point);
	istream& operator>>(istream& In , RVMpoint& Point);
}

#endif
