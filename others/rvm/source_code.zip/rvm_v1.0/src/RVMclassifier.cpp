/* RVM++: Relevance Vector Machine in C++
 *
 * Copyright (C) 2008 XIAO Jianxiong
 *
 * http://www.cse.ust.hk/~csxjx/
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include "RVMconstant.h"
#include "RVMclassifier.h"
#include "RVMmatrix.h"
#include <cmath>
using namespace std;

namespace RVM
{
	RVMclassifier::RVMclassifier():RVMmachine()
	{

	}
	RVMclassifier::RVMclassifier(RVMdataset* _training,RVMkernel* _kernel,
			unsigned int _maxIts,bool _withBias,double _initAlpha)
		:RVMmachine(_training,_kernel,_maxIts,_withBias,_initAlpha)
	{
	}

	void RVMclassifier::predictPoint(RVMpoint* curPt)
	{
		RVMmachine::predictPoint(curPt);
		curPt->SetNewLabel( sigmoid(curPt->GetNewLabel()) );
	}

	void RVMclassifier::estimate(RVMmatrix const & PHI,RVMmatrix const & t, RVMmatrix const & alpha, 
		RVMmatrix & w, RVMmatrix & Ui, double & betaED, double & logBeta, double beta, unsigned int ptNum,double& ED)
	{
		//cerr<<"w: "<<w;

		//cerr<<"alpha: "<<alpha;

		unsigned int i,j,k;
		unsigned int N = PHI.GetRows();
		unsigned int d = PHI.GetCols();
		unsigned int M = w.GetRows();
		RVMmatrix A(diag(alpha));
		RVMmatrix errs(PM_MAXITS,1);	errs.Fill(0);
		RVMmatrix PHIw(PHI*w);
		RVMmatrix y(sigmoid(PHIw));
		double TOL = M * STOP_CRITERION;
		TOL *= TOL;

		double data_term=0.0;
		for (i=0;i<t.GetRows();++i)
		{
			if (t._(i)>0.5)
			{
				data_term += log(y._(i));
			}else
			{
				data_term += log(1.0-y._(i));
			}
		}
		data_term = - data_term;
		//data_term /= - double(N);
		double regulariser= Dot(alpha,Mpow(w,2));
		regulariser /= 2.0;
		//regulariser /= double(2 * N);
		double err_new = data_term + regulariser;

	//	cerr<<"data_term="<<data_term<<endl;
	//	cerr<<"regulariser="<<regulariser<<endl;
	//	cerr<<"err_new="<<err_new<<endl;

		RVMmatrix vary(N,1);	// diagonal of B
		RVMmatrix PHIV(N,d);	// PHI'B
		RVMmatrix e(N,1);			// (t-y)
		RVMmatrix Gradient(d,1);
		RVMmatrix Hessian (d,d);
		RVMmatrix U(d,d);		// Cholesky factorization: U'*U = Hessian

		for (i=0;i<PM_MAXITS;++i)
		{
			for (j=0;j<N;++j)
			{
				double y_j = y._(j);
				double varyJ = y_j * (1.0-y_j);
				vary(j) = varyJ;
				for (k=0;k<d;++k)
					PHIV(j,k) = PHI._(j,k) * varyJ;
			}
			e = t-y;
			
			//Gradient
			Gradient = PHI.Transpose_() * e;
			for (j=0;j<d;++j)
			{
				Gradient(j) -= alpha._(j) * w._(j);
			}

			if (i!=0 &&  Gradient.SqrNorm() < TOL)
			{
				break;
			}

			//cerr<<"Gradient: "<<Gradient;

			//Hessian
			Hessian = PHIV.Transpose_() * PHI + A;

			//cerr<<"Hessian: "<<Hessian;

			//record error
			errs(i) = err_new;

			//Cholesky factorization: U'*U = Hessian
			chol(Hessian,U);

			//Change of w
			Ui = U;
			RVMmatrix Uti(U.Transpose_());	// inv(U')
			RVMmatrix delta_w(Gradient);
			gaussj(Uti,delta_w);
			gaussj(Ui,delta_w);

			
			//cerr<<"delta_w: "<<delta_w;

			double lambda=1.0;
			while(lambda>LAMBDA_MIN)
			{
				RVMmatrix w_new(w+lambda*delta_w);	//new w
				PHIw = PHI*w_new;					//new PHI*w
				y = sigmoid(PHIw);					//new y

				bool complete_invert = false;

				for (j=0;j<N;++j)
					if (y(j)==1.0-t._(j))
					{
						complete_invert = true;
						break;
					}

				if (complete_invert)
				{
					err_new = errs._(i) +1;
				}else
				{
					data_term=0.0;
					for (j=0;j<t.GetRows();++j)
					{
						if (t._(j)>0.5)
						{
							data_term += log(y._(j));
						}else
						{
							data_term += log(1.0-y._(j));
						}
					}
					data_term = - data_term;
					//data_term /= - double(N);
					regulariser= Dot(alpha,Mpow(w_new,2)) / 2.0;
					//regulariser= Dot(alpha,Mpow(w_new,2)) / double(2*N);
					err_new = data_term + regulariser;
				}

				if (err_new > errs._(i))
				{
					lambda	= lambda/2;
				}else
				{
					w = w_new;
					lambda = 0.0;
				}
			}
		}

		betaED = 0.0;
		for (i=0;i<e.GetRows();++i)
			betaED += e._(i) * e._(i) * vary._(i);

		logBeta	= 0.0;

	}
}
