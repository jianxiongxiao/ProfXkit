/* RVM++: Relevance Vector Machine in C++
 *
 * Copyright (C) 2008 XIAO Jianxiong
 *
 * http://www.cse.ust.hk/~csxjx/
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include "RVMdataset.h"
#include <cmath>
#include <fstream>
using namespace std;

namespace RVM
{
	RVMdataset::RVMdataset()
	{
	}

	RVMdataset::RVMdataset(char* filename)
	{
		load(filename);
	}

	RVMdataset::~RVMdataset()
	{
		for (vector<RVMpoint*>::iterator it=data.begin();it!=data.end();++it)
		{
			delete (*it);
		}
	}

	double RVMdataset::OldLabelSTD()
	{
		double result=0.0;
		double mean = 0.0;
		vector<RVMpoint*>::iterator it;
		for (it=data.begin();it!=data.end();++it)
		{
			mean += (*it)->GetOldLabel();
		}
		mean /= double(data.size());
		for (it=data.begin();it!=data.end();++it)
		{
			double diff = (*it)->GetOldLabel()-mean;
			result += diff*diff;
		}
		result /= double(data.size());
		return sqrt(result);
	}

	void RVMdataset::clear()
	{
		data.clear();
	}

	void RVMdataset::load(char* filename)
	{
		ifstream fin(filename);
		fin>>(*this);
		fin.close();
	}

	void RVMdataset::save(char* filename)
	{
		ofstream fout(filename);
		fout<<(*this);
		fout.close();
	}

	void RVMdataset::append(RVMpoint* newpt)
	{
		data.push_back(newpt);
	}

	double RVMdataset::GetClassificationError()
	{
		unsigned int ErrCnt = 0;
		for (vector<RVMpoint*>::iterator it=data.begin();it!=data.end();++it)
		{
			double newLabel = (*it)->GetNewLabel();
			double oldLabel = (*it)->GetOldLabel();
			
			if( (newLabel<=0.5 && oldLabel>0.5) || (newLabel>=0.5 && oldLabel<0.5) )
			{
				++ErrCnt;
			}
		}
		return double(ErrCnt)/double(data.size());
	}

	ostream& operator<<(ostream& Out, const RVMdataset& Dataset)
	{
		for (unsigned int i=0;i<Dataset.GetSize();i++)
		{
			Out<< (*(Dataset(i)));
		}
		return Out;
	}

	istream& operator>>(istream& In , RVMdataset& Dataset)
	{
		while (!In.eof())
		{
			RVMpoint* newpt = new RVMpoint();
			In >> (*newpt);
			Dataset.append(newpt);
		}
		return In;
	}
}
