/* RVM++: Relevance Vector Machine in C++
 *
 * Copyright (C) 2008 XIAO Jianxiong
 *
 * http://www.cse.ust.hk/~csxjx/
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#ifndef RVMDATASET_H
#define RVMDATASET_H

#include <vector>
#include <iostream>
#include "RVMpoint.h"
using namespace std;

namespace RVM
{
	class RVMdataset
	{
	public:
		RVMdataset();
		RVMdataset(char* filename);
		~RVMdataset();
		inline unsigned int GetSize() const;
		inline RVMpoint* operator()(unsigned int index) const;
		void clear();
		void load(char* filename);
		void save(char* filename);
		void append(RVMpoint* newpt);
		double OldLabelSTD();
		double GetClassificationError();
	private:
		vector<RVMpoint*> data;
	};

	inline unsigned int RVMdataset::GetSize() const
	{
		return data.size();
	}

	inline RVMpoint* RVMdataset::operator()(unsigned int index) const
	{
		return data[index];
	}

	ostream& operator<<(ostream& Out, const RVMdataset& Dataset);
	istream& operator>>(istream& In , RVMdataset& Dataset);
}

#endif
