/* RVM++: Relevance Vector Machine in C++
 *
 * Copyright (C) 2008 XIAO Jianxiong
 *
 * http://www.cse.ust.hk/~csxjx/
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#ifndef RVMMATRIX_H
#define RVMMATRIX_H

#include <iostream>
using namespace std;

namespace RVM
{
	class RVMmatrix
	{
	public:
		RVMmatrix();
		RVMmatrix(unsigned int _rows,unsigned int _cols);		
		RVMmatrix(const RVMmatrix& Matrix);
		~RVMmatrix();

		// For general matrix
		inline unsigned int GetRows() const;
		inline unsigned int GetCols() const;
		inline void Allocate(unsigned int _rows,unsigned int _cols);

		void Fill(double Fill_=0);
		inline double _(unsigned int no_row, unsigned int no_col) const ;
		inline double& operator()(unsigned int no_row, unsigned int no_col);
		RVMmatrix Transpose_() const;
		void Transpose();
		
		const RVMmatrix& operator= (const RVMmatrix& Matrix);
		const RVMmatrix& operator+=(const RVMmatrix& Matrix);
		const RVMmatrix& operator-=(const RVMmatrix& Matrix);
		const RVMmatrix& operator*=(double scalar);
		const RVMmatrix& operator/=(double scalar);

		// For square matrix
		inline bool IsSquareMatrix() const ;
		inline double Trace() const ;

		// For vectors
		inline bool IsVector() const ;
		inline double _(unsigned int no_row) const ;
		inline double& operator()(unsigned int no_row);
		inline double SqrNorm() const;

	private:
		unsigned int rows;
		unsigned int cols;
		double* values;
	};

	RVMmatrix operator+(const RVMmatrix& Matrix0,const RVMmatrix&Matrix1);
	RVMmatrix operator-(const RVMmatrix& Matrix0, const RVMmatrix& Matrix1);
	RVMmatrix operator*(const RVMmatrix& Matrix0, const RVMmatrix& Matrix1);
	RVMmatrix operator*(double a, const RVMmatrix& Matrix);
	RVMmatrix operator*(const RVMmatrix& Matrix, double a);
	RVMmatrix operator/(const RVMmatrix& Matrix, double a);
	ostream& operator<<(ostream& Out, const RVMmatrix& Matrix);
	
	double Dot(const RVMmatrix& Matrix0,const RVMmatrix&Matrix1);	//Dot product for vector
	RVMmatrix diag(const RVMmatrix& Matrix);
	RVMmatrix sum(const RVMmatrix& Matrix,unsigned char Dim=1);
	RVMmatrix Mlog(const RVMmatrix& Matrix);
	RVMmatrix Mpow(const RVMmatrix& Matrix,double exponent=1.0);
	RVMmatrix sigmoid(const RVMmatrix& Matrix);

	//Given a positive-definite symmetric matrix, get its Cholesky decomposition  A=L*L'
	void cholesky(RVMmatrix &Matrix);			//Will Destroyed Input Matrix
	// Assume X is positive definite, then U = chol(X) produces an upper triangular U so that U'*U = X
    void chol(const RVMmatrix& Matrix, RVMmatrix& U);
	// Linear equation solution by Gauss-Jordan elimination
	void gaussj(RVMmatrix &a, RVMmatrix &b);	//Will Destroyed Input Matrix
	// Overloaded version with no right-hand sides. Replaces a by its inverse
	void gaussj(RVMmatrix &a);


	//////////////////////////////////////////////////////////////////////////

	inline double& RVMmatrix::operator()(unsigned int no_row)
	{
		if (GetCols()*GetRows()<= no_row)
		{
			cerr<<"Fatal Error: Matrix Index Out of Range in RVMmatrix::_ "<<endl;
			exit(1);
		}
		return values[no_row];
	}

	inline double RVMmatrix::_(unsigned int no_row) const
	{
		if (GetCols()*GetRows()<= no_row)
		{
			cerr<<"Fatal Error: Matrix Index Out of Range in RVMmatrix::_ "<<endl;
			exit(1);
		}
		return values[no_row];
	}

	inline double RVMmatrix::_(unsigned int no_row, unsigned int no_col) const
	{
		if (no_row>=GetRows() || no_col>=GetCols() || values==NULL)
		{
			cerr<<"Fatal Error: Matrix Index Out of Range in RVMmatrix::_"<<endl;
			exit(1);
		}
		unsigned int index= no_row*GetCols() + no_col;
		return values[index];
	}
	
	inline double& RVMmatrix::operator()(unsigned int no_row, unsigned int no_col)
	{
		if (no_row>=GetRows() || no_col>=GetCols() || values==NULL)
		{
			cerr<<"Fatal Error: Matrix Index Out of Range in RVMmatrix::operator() "<<endl;
			exit(1);
		}
		unsigned int index= no_row*GetCols() + no_col;
		return values[index];
	}
	
	inline bool RVMmatrix::IsSquareMatrix() const { return (GetCols()== GetRows()); }
	
	inline double RVMmatrix::Trace() const
	{
		double Result= 0;
		unsigned int kMax= (GetCols()>GetRows())? GetRows() : GetCols();
		for (unsigned int k= 0; k< kMax; k++)
			Result+= _(k, k);
		return Result;
	}
	
	inline bool RVMmatrix::IsVector() const
	{
		return GetCols()==1;
	}

	inline unsigned int RVMmatrix::GetRows() const
	{
		return rows;
	}
	inline unsigned int RVMmatrix::GetCols() const
	{
		return cols;
	}
	inline double RVMmatrix::SqrNorm() const
	{
		double result=0.0;
		for (unsigned int i=0;i<rows;++i)
		{
			double element = this->_(i,0);
			result += element * element;
		}
		return result;
	}
}

#endif

