/* Sum-product Loopy Belief Propagation for High-order Markov Random Field
*
* Copyright (C) 2008 XIAO Jianxiong
*
* http://www.cse.ust.hk/~csxjx/
*
* This program is free software: you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation, either version 3 of the License, or
* (at your option) any later version.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include "StdAfx.h"
#include <cmath>
#include "BPRandomField.h"


namespace BPRandomField
{

	MsgV2F::MsgV2F(VariableNode* _from,FactorNode* _to,unsigned int valueRange)
		:from(_from),to(_to)
	{
		for (unsigned int i=0;i<2;i++)
			msg[i].resize(valueRange);
	}

	MsgF2V::MsgF2V(FactorNode* _from,VariableNode* _to,unsigned int valueRange)
		:from(_from),to(_to)
	{
		for (unsigned int i=0;i<2;i++)
			msg[i].resize(valueRange);
	}

	void LBP::ClearMsg()
	{
		for (unsigned int i=0;i<mV2F.size();++i)		delete mV2F[i];
		for (unsigned int i=0;i<mF2V.size();++i)		delete mF2V[i];
		mV2F.clear();
		mF2V.clear();
	}

	void LBP::AllocateMsg()
	{
		for (unsigned int i=0;i<g.factor.size();i++)
		{
			for (unsigned int j=0;j< (g.factor[i])->neighbor.size(); j++)
			{
				MsgF2V* m = new MsgF2V(g.factor[i],(g.factor[i])->neighbor[j],valueRange);
				mF2V.push_back(m);
				g.factor[i]->mF2V.push_back(m);
				(g.factor[i])->neighbor[j]->mF2V.push_back(m);
			}
		}
		for (unsigned int i=0;i<g.variable.size();i++)
		{
			for (unsigned int j=0;j< (g.variable[i])->neighbor.size(); j++)
			{
				MsgV2F* m = new MsgV2F(g.variable[i],(g.variable[i])->neighbor[j],valueRange);
				mV2F.push_back(m);
				g.variable[i]->mV2F.push_back(m);
				(g.variable[i])->neighbor[j]->mV2F.push_back(m);
			}
		}
	}

	void LBP::NormalizeAllMsg(unsigned int which)
	{
		//scale msg
		for (int i=0;i<mF2V.size();i++)
		{
			long double sum = 0.0;
			for (int k=0;k<valueRange;k++)
				sum += mF2V[i]->msg[which][k];
			for (int k=0;k<valueRange;k++)
				mF2V[i]->msg[which][k] /= sum;
		}
		for (int i=0;i<mV2F.size();i++)
		{
			long double sum = 0.0;
			for (int k=0;k<valueRange;k++)
				sum += mV2F[i]->msg[which][k];
			for (int k=0;k<valueRange;k++)
				mV2F[i]->msg[which][k] /= sum;
		}
	}

	void LBP::AvoidZeroMsg(unsigned int which)
	{
		//scale msg
		for (int i=0;i<mF2V.size();i++)
		{
			long double sum = 0.0;
			for (int k=0;k<valueRange;k++)
				sum += mF2V[i]->msg[which][k];
			if (sum<0.0000000001 * valueRange)
			{
				for (int k=0;k<valueRange;k++)
					mF2V[i]->msg[which][k] = 0.0000000001;
			}else
			{
				for (int k=0;k<valueRange;k++)
					mF2V[i]->msg[which][k] /= sum;
				for (int k=0;k<valueRange;k++)
					if (mF2V[i]->msg[which][k] < 0.0000000001)
						mF2V[i]->msg[which][k] = 0.0000000001;
				long double sum1 = 0.0;
				for (int k=0;k<valueRange;k++)
					sum1 += mF2V[i]->msg[which][k];
				for (int k=0;k<valueRange;k++)
					mF2V[i]->msg[which][k] *= sum/sum1;
			}
		}
		for (int i=0;i<mV2F.size();i++)
		{
			long double sum = 0.0;
			for (int k=0;k<valueRange;k++)
				sum += mV2F[i]->msg[which][k];
			if (sum<0.0000000001 * valueRange)
			{
				for (int k=0;k<valueRange;k++)
					mV2F[i]->msg[which][k] = 0.0000000001;
			}else
			{
				for (int k=0;k<valueRange;k++)
					mV2F[i]->msg[which][k] /= sum;
				for (int k=0;k<valueRange;k++)
					if (mV2F[i]->msg[which][k] < 0.0000000001)
						mV2F[i]->msg[which][k] = 0.0000000001;
				long double sum1 = 0.0;
				for (int k=0;k<valueRange;k++)
					sum1 += mV2F[i]->msg[which][k];
				for (int k=0;k<valueRange;k++)
					mV2F[i]->msg[which][k] *= sum/sum1;
			}
		}
	}


	void LBP::ScaleAllMsgFactor(long double scaler,unsigned int which)
	{
		//scale msg
		for (int i=0;i<mF2V.size();i++)
			for (int k=0;k<valueRange;k++)
				mF2V[i]->msg[which][k] *= scaler;
		for (int i=0;i<mV2F.size();i++)
			for (int k=0;k<valueRange;k++)
				mV2F[i]->msg[which][k] *= scaler;
		//scale factor
		for (int i=0;i<g.factor.size();i++)
			g.factor[i]->scale *= scaler;
	}

	vector<long double> LBP::SumProductBPResult(VariableNode* node)
	{
		vector<long double> result;
		result.resize(valueRange);
		for(unsigned int k=0;k<valueRange;k++)
		{
			result[k]=1;
			for (unsigned int j=0;j<node->mF2V.size();j++)
			{
				result[k] *= node->mF2V[j]->msg[0][k];
			}
		}
		return result;
	}

	//The user need to normalize the potential function by a constant scaler in order to prevent under/over-flow
	void LBP::SumProductLBPRun(unsigned int nMaxIts,bool initial)
	{
		if (initial)
		{
			for (unsigned int i=0;i<mV2F.size();i++)
				for (unsigned int k=0;k<valueRange;k++)
					mV2F[i]->msg[0][k]=1.0;

			for (unsigned int i=0;i<mF2V.size();i++)
				for (unsigned int k=0;k<valueRange;k++)
					mF2V[i]->msg[0][k]=1.0;
		}

		if(nMaxIts%2==1)	nMaxIts++;
		for (unsigned int t=0;t<nMaxIts;t++)
		{
			long double sum = 0.0;
			unsigned long cntMsg = 0;

			unsigned int prev=t%2;
			unsigned int next=(t+1)%2;

			NormalizeAllMsg(prev);
			

			for (unsigned int i=0;i<mV2F.size();i++)
			{
				for (unsigned int k=0;k<valueRange;k++)
				{
					mV2F[i]->msg[next][k]=1;
					for (unsigned int j=0;j<mV2F[i]->from->mF2V.size();j++)
					{
						if (mV2F[i]->from->mF2V[j]->from != mV2F[i]->to)
						{
							mV2F[i]->msg[next][k] *= mV2F[i]->from->mF2V[j]->msg[prev][k];
						}
					}

					sum += mV2F[i]->msg[next][k];
					cntMsg ++;
				}
			}

			for (unsigned int i=0;i<mF2V.size();i++)
			{

				unsigned int clique	[MAX_CLIQUE];
				unsigned int lower	[MAX_CLIQUE];
				unsigned int upper	[MAX_CLIQUE];
				unsigned int idxto;
				unsigned int cliquesize = mF2V[i]->from->mV2F.size(); 
				for (unsigned int j=0;j<MAX_CLIQUE;j++)
				{
					if(j<cliquesize)
					{
						if (mF2V[i]->from->mV2F[j]->from == mF2V[i]->to)
						{
							idxto=j;
						}else
						{
							lower[j]=0;
							upper[j]=valueRange;
						}
					}else
					{
						lower[j]=0;
						upper[j]=1;
					}
				}

				for (unsigned int k=0;k<valueRange;k++)
				{
					lower[idxto] = k;
					upper[idxto] = k+1;

					mF2V[i]->msg[next][k]=0;

					for(clique[0]=lower[0];clique[0]<upper[0];clique[0]++)
					for(clique[1]=lower[1];clique[1]<upper[1];clique[1]++)
					for(clique[2]=lower[2];clique[2]<upper[2];clique[2]++)
					for(clique[3]=lower[3];clique[3]<upper[3];clique[3]++)
					for(clique[4]=lower[4];clique[4]<upper[4];clique[4]++)
					for(clique[5]=lower[5];clique[5]<upper[5];clique[5]++)
					for(clique[6]=lower[6];clique[6]<upper[6];clique[6]++)
					for(clique[7]=lower[7];clique[7]<upper[7];clique[7]++)
					for(clique[8]=lower[8];clique[8]<upper[8];clique[8]++)
					for(clique[9]=lower[9];clique[9]<upper[9];clique[9]++)
					{
						long double val = ((mF2V[i]->from->potential))(clique);
						for(unsigned int j=0;j<cliquesize;j++)
						{
							if(j!=idxto)
							{
								val *= mF2V[i]->from->mV2F[j]->msg[prev][clique[j]];
							}
						}
						mF2V[i]->msg[next][k]+=val;
					}

					sum += mF2V[i]->msg[next][k];
					cntMsg ++;
				}
			}

			long double mean =  sum / (long double)( cntMsg );

			//Normalize the messages
			//ScaleAllMsgFactor(1.0/mean,next);
			//AvoidZeroMsg(next);

		}
	}

	FactorNode::FactorNode()
	{
		scale = 1.0;
	}

	//Example Unary and Pairwise Potential Function for Binary Random Variables (Used in Lazy Snapping ToG 2004)
	long double FactorNode::potential(unsigned int neighbor_values[MAX_CLIQUE])
	{
		long double value[2];
		long double sum;
		switch (neighbor.size())
		{
		case 1:
			value[0] = exp(-parameters[0]);	value[1] = exp(-parameters[1]);
			sum = value[0] + value[1];		value[0] /= sum;		value[1] /= sum;

			if(value[0]<0.000000000000000001){	value[0] = 0.000000000000000001;	value[1] = 0.999999999999999999; }
			if(value[1]<0.000000000000000001){	value[0] = 0.999999999999999999;	value[1] = 0.000000000000000001; }

			return scale * value[neighbor_values[0]] * sum;
			break;
		case 2:
			value[0] = exp(-0.0);	value[1] = exp(-parameters[0]);
			sum = value[0] + value[1];		value[0] /= sum;		value[1] /= sum;

			if(value[0]<0.000000000000000001){	value[0] = 0.000000000000000001;	value[1] = 0.999999999999999999; }
			if(value[1]<0.000000000000000001){	value[0] = 0.999999999999999999;	value[1] = 0.000000000000000001; }

			if (neighbor_values[0]==neighbor_values[1])
				return scale * value[0] * sum;
			else
				return scale * value[1] * sum;
			break;
		default:
			break;
		}
	}

	Graph::~Graph()
	{
		for (int i=0;i<factor.size();i++)
		{
			delete factor[i];
		}
		for (int i=0;i<variable.size();i++)
		{
			delete variable[i];
		}		
	}

	LBP::~LBP()
	{
		ClearMsg();
	}
};