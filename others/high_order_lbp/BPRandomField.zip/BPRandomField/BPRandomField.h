/* Sum-product Loopy Belief Propagation for High-order Markov Random Field
*
* Copyright (C) 2008 XIAO Jianxiong
*
* http://www.cse.ust.hk/~csxjx/
*
* This program is free software: you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation, either version 3 of the License, or
* (at your option) any later version.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#ifndef BPRANDOMFIELD_H
#define BPRANDOMFIELD_H

#include <vector>
using namespace std;

#define MAX_CLIQUE 10

namespace BPRandomField
{

	class VariableNode;
	class FactorNode;
	class MsgV2F;
	class MsgF2V;

	class VariableNode
	{
	public:
		vector<MsgV2F*> mV2F;
		vector<MsgF2V*> mF2V;

		vector<FactorNode*> neighbor;
	};

	class FactorNode
	{
	public:
		FactorNode();
		vector<MsgV2F*> mV2F;
		vector<MsgF2V*> mF2V;

		vector<VariableNode*> neighbor;

		long double scale;
		vector<long double> parameters;
		long double potential(unsigned int neighbor_values[MAX_CLIQUE]);
	};

	class MsgV2F
	{
	public:
		VariableNode*	from;
		FactorNode*		to;
		vector<long double>	msg[2];	//ping pong update
		MsgV2F(VariableNode* _from,FactorNode* _to,unsigned int valueRange);
	};

	class MsgF2V
	{
	public:
		FactorNode*		from;
		VariableNode*	to;
		vector<long double>	msg[2];	//ping pong update
		MsgF2V(FactorNode* _from,VariableNode* _to,unsigned int valueRange);
	};

	class Graph
	{
	public:
		vector<FactorNode*>		factor;
		vector<VariableNode*>	variable;
		~Graph();
	};


	class LBP
	{
	public:
		~LBP();
		Graph g;
		vector<MsgV2F*> mV2F;
		vector<MsgF2V*> mF2V;
		unsigned int valueRange;

		void ClearMsg();
		void AllocateMsg();

		vector<long double> SumProductBPResult(VariableNode* node);
		void SumProductLBPRun(unsigned int nMaxIts=50,bool initial=true);
		void ScaleAllMsgFactor(long double scaler,unsigned int which);
		void NormalizeAllMsg(unsigned int which);
		void AvoidZeroMsg(unsigned int which);
	};
}

#endif