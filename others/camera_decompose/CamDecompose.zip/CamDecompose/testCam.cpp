/* Camera Decomposition from Projection Matrix
*
* Copyright (C) 2008 XIAO Jianxiong
*
* http://www.cse.ust.hk/~csxjx/
*
* This program is free software: you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation, either version 3 of the License, or
* (at your option) any later version.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/


#include "Camera.h"

#include <iostream>
using namespace std;

int main()
{
	double c[12];
	c[0]=-0.54628;		c[1]=0.258106;		c[2]=-0.28693;		c[3]=0.265323;
	c[4]=0.01217;		c[5]=0.615108;		c[6]=0.322023;		c[7]=-0.00537576;
	c[8]=0.000246694;	c[9]=0.000670333;	c[10]=-0.00051707;	c[11]=0.000760138;

	//Decompose
	Camera obj(c);

	//Re-compose
	obj.Compose();

	//Compare the recomposed one with the truth
	for (int i=0;i<3;i++)
	{
		for (int j=0;j<4;j++)
		{
			cout<<obj.matrix[i*4+j]/c[i*4+j]<<"\t";
		}
		cout<<endl;
	}
	cout<<endl;



	return 0;
}