/* Camera Decomposition from Projection Matrix
*
* Copyright (C) 2008 XIAO Jianxiong
*
* http://www.cse.ust.hk/~csxjx/
*
* This program is free software: you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation, either version 3 of the License, or
* (at your option) any later version.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

class Camera
{
public:
	Camera(const Camera& other);
	Camera(double* c);
	Camera();
	~Camera(void);

	// matrix[0] matrix[1] matrix[2]  matrix[3]
	// matrix[4] matrix[5] matrix[6]  matrix[7]
	// matrix[8] matrix[9] matrix[10] matrix[11]
	double	matrix[12];
	double	heightAngle;
	double	aspectRatio;
	double	rotMat[16];
	void	Update(double* c);
	double	t[3];
	double	R4x4[16];
	void	Cam2World(double xyz[4]);
	void	World2Cam(double xyz[4]);
	double	alpha_u;
	double	alpha_v;

	void	Compose();

	// P = KR[I|-C]
	double  f_len;
	double	u0,v0;
	double	position[3];

	double	upDirection[3];
	double	forwardDirection[3];
	double	rightDirection[3];
private:
	double	Det(double* v);
	double*	Inv3x3(double* v);
	double	dot(double* a,double* b);
};
