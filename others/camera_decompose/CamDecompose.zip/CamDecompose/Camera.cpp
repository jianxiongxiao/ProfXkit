/* Camera Decomposition from Projection Matrix
*
* Copyright (C) 2008 XIAO Jianxiong
*
* http://www.cse.ust.hk/~csxjx/
*
* This program is free software: you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation, either version 3 of the License, or
* (at your option) any later version.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#include "Camera.h"
#include <cmath>

double Camera::Det(double* v)
{
	return v[0]*v[4]*v[8] + v[1]*v[5]*v[6] + v[2]*v[3]*v[7]	-v[2]*v[4]*v[6] - v[0]*v[5]*v[7] - v[1]*v[3]*v[8];
}

double* Camera::Inv3x3(double* v)
{
	double d = Det(v);
	double* _v = new double[9];
	_v[0] = v[4]*v[8] - v[5]*v[7];
	_v[1] = v[7]*v[2] - v[1]*v[8];
	_v[2] = v[1]*v[5] - v[4]*v[2];
	_v[3] = v[5]*v[6] - v[3]*v[8];
	_v[4] = v[0]*v[8] - v[6]*v[2];
	_v[5] = v[3]*v[2] - v[0]*v[5];
	_v[6] = v[3]*v[7] - v[4]*v[6];
	_v[7] = v[6]*v[1] - v[0]*v[7];
	_v[8] = v[4]*v[0] - v[3]*v[1];

	for(int n = 0; n < 9; n++)	_v[n] = _v[n] / d;
	return _v;
}

double Camera::dot(double* a,double* b)
{
	return a[0]*b[0]+a[1]*b[1]+a[2]*b[2];
}

Camera::Camera(double* c)
{
	Update(c);
}

Camera::Camera()
{
}

Camera::Camera(const Camera& other)
{
	for(int i=0;i<12;i++)
		matrix[i]=other.matrix[i];
	heightAngle=other.heightAngle;
	aspectRatio=other.aspectRatio;
	for (int i=0;i<16;i++)
	{
		rotMat[i]=other.rotMat[i];
		R4x4  [i]=other.R4x4  [i];
	}
	for (int i=0;i<3;i++)
	{
		position[i]=other.position[i];
		t[i]=other.t[i];

		upDirection[i]=other.upDirection[i];
		rightDirection[i]=other.rightDirection[i];
		forwardDirection[i]=other.forwardDirection[i];
	}
	f_len = other.f_len;
	u0 = other.u0;
	v0 = other.v0;
}

/*
K = [ alpha_u           u0 ]
    [          alpha_v  v0 ]
	[                    1 ]
*/
void Camera::Update(double* c)
{
	for(int i=0;i<12;i++)
		matrix[i]=c[i];

	double R[9];
	double* q1 = &(c[0]);	//(c[0], c[1], c[2]);
	double* q2 = &(c[4]);	//(c[4], c[5], c[6]);
	double* q3 = &(c[8]);	//(c[8], c[9], c[10]);

	//Rotation R;
	//Vector3f t;
	double p = 1/sqrt(dot(q3,q3));

	//	R.SetRow(2, p * q3);	//r3 = p * q3;
	R[2+3*0] = p * q3[0];	R[2+3*1] = p * q3[1];	R[2+3*2] = p * q3[2];

	u0 = p * p * dot(q1,q3);
	v0 = p * p * dot(q2,q3);

	//printf("u0 = %f\t",u0);
	//printf("v0 = %f\n", v0);

	alpha_u = sqrt(p*p*dot(q1,q1) - u0*u0);
	alpha_v = sqrt(p*p*dot(q2,q2) - v0*v0);

	f_len = (alpha_u+alpha_v)/2.0;


	//printf("alpha_u = %f\t", alpha_u);
	//printf("alpha_v = %f\t", alpha_v);
	//printf("focal length = %f\n", f_len);

	//R.SetRow(0, p * (q1 - (u0*q3))/alpha_u);	//r1 = p * (q1 - (u0*q3))/alpha_u;
	R[0+3*0] = p * (q1[0] - (u0*q3[0]))/alpha_u ;	R[0+3*1] = p * (q1[1] - (u0*q3[1]))/alpha_u ;	R[0+3*2] = p * (q1[2] - (u0*q3[2]))/alpha_u ;

	//R.SetRow(1, p * (q2 - (v0*q3))/alpha_v);	//r2 = p * (q2 - (v0*q3))/alpha_v;
	R[1+3*0] = p * (q2[0] - (v0*q3[0]))/alpha_v ;	R[1+3*1] = p * (q2[1] - (v0*q3[1]))/alpha_v ;	R[1+3*2] = p * (q2[2] - (v0*q3[2]))/alpha_v ;

	t[0] = p * (c[3] - u0*c[11]) / alpha_u;
	t[1] = p * (c[7] - v0*c[11]) / alpha_v;
	t[2] = p * c[11];

	//ext.SetRotation(R);
	//ext.SetTranslation(t);
	double* InvR = Inv3x3(R);
	position[0] =  InvR[0]  * (-t[0]) + InvR[3]  * (-t[1]) + InvR[6]  * (-t[2]);
	position[1] =  InvR[1]  * (-t[0]) + InvR[4]  * (-t[1]) + InvR[7]  * (-t[2]);
	position[2] =  InvR[2]  * (-t[0]) + InvR[5]  * (-t[1]) + InvR[8]  * (-t[2]);
	delete [] InvR;


	R4x4  [0]  = double(R[0])	;
	R4x4  [1]  = double(R[3])	;
	R4x4  [2]  = double(R[6])	;
	R4x4  [3]  = double(0	)	;
	R4x4  [4]  = double(R[1])	;
	R4x4  [5]  = double(R[4])	;
	R4x4  [6]  = double(R[7])	;
	R4x4  [7]  = double(0	)	;
	R4x4  [8]  = double(R[2])	;
	R4x4  [9]  = double(R[5])	;
	R4x4  [10] = double(R[8])	;
	R4x4  [11] = double(0	)	;
	R4x4  [12] = double(0	)	;
	R4x4  [13] = double(0	)	;
	R4x4  [14] = double(0	)	;
	R4x4  [15] = double(1	)	;

	// transform from OpenGL coordinate system to imaging coordinate system by inverting Y and Z coordinates of object
	//rot.SetIdentity();	rot[4] = -1;	rot[8] = -1;
	//rot *= cam.Rot();
	R[1]=-R[1];
	R[2]=-R[2];
	R[4]=-R[4];
	R[5]=-R[5];
	R[7]=-R[7];
	R[8]=-R[8];

	heightAngle = 2*atan(v0 / alpha_v)  * 180 / (2.0 * acos(0.0));
	aspectRatio = u0 / v0;
	//position[0] = - position[0];
	//position[1] = - position[1];
	//position[2] = - position[2];

	//printf("heightAngle = %f\t", heightAngle);
	//printf("aspectRatio = %f\n", aspectRatio);

	//printf("Position = (%f,\t%f,\t%f)\n", position[0], position[1], position[2]);

/*
	rotMat[0]  = double(R[0])	;
	rotMat[1]  = double(R[3])	;
	rotMat[2]  = double(R[6])	;
	rotMat[3]  = double(0	)	;
	rotMat[4]  = double(R[1])	;
	rotMat[5]  = double(R[4])	;
	rotMat[6]  = double(R[7])	;
	rotMat[7]  = double(0	)	;
	rotMat[8]  = double(R[2])	;
	rotMat[9]  = double(R[5])	;
	rotMat[10] = double(R[8])	;
	rotMat[11] = double(0	)	;
	rotMat[12] = double(0	)	;
	rotMat[13] = double(0	)	;
	rotMat[14] = double(0	)	;
	rotMat[15] = double(1	)	;
*/

	rotMat[0]  = double(R[0])	;
	rotMat[1]  = double(R[1])	;
	rotMat[2]  = double(R[2])	;
	rotMat[3]  = double(0	)	;
	rotMat[4]  = double(R[3])	;
	rotMat[5]  = double(R[4])	;
	rotMat[6]  = double(R[5])	;
	rotMat[7]  = double(0	)	;
	rotMat[8]  = double(R[6])	;
	rotMat[9]  = double(R[7])	;
	rotMat[10] = double(R[8])	;
	rotMat[11] = double(0	)	;
	rotMat[12] = double(0	)	;
	rotMat[13] = double(0	)	;
	rotMat[14] = double(0	)	;
	rotMat[15] = double(1	)	;

	rightDirection[0]	= R[0];
	rightDirection[1]	= R[3];
	rightDirection[2]	= R[6];

	//printf("rightDirection = (%f,\t%f,\t%f)\n", rightDirection[0], rightDirection[1], rightDirection[2]);

	upDirection[0]		= R[1];
	upDirection[1]		= R[4];
	upDirection[2]		= R[7];

	//printf("upDirection = (%f,\t%f,\t%f)\n", upDirection[0], upDirection[1], upDirection[2]);

	forwardDirection[0]	= -R[2];
	forwardDirection[1]	= -R[5];
	forwardDirection[2]	= -R[8];

	//printf("forwardDirection = (%f,\t%f,\t%f)\n", forwardDirection[0], forwardDirection[1], forwardDirection[2]);

	//printf("\n");
}

void Camera::Cam2World(double xyz[4])
{
	double newxyz[4];
	double invRotMat[16];
	invRotMat[ 0]=R4x4[ 0];	invRotMat [1]=R4x4[ 4];	invRotMat[ 2]=R4x4[ 8];	invRotMat[ 3]=R4x4[ 3];
	invRotMat[ 4]=R4x4[ 1];	invRotMat[ 5]=R4x4[ 5];	invRotMat[ 6]=R4x4[ 9];	invRotMat[ 7]=R4x4[ 7];
	invRotMat[ 8]=R4x4[ 2];	invRotMat[ 9]=R4x4[ 6];	invRotMat[10]=R4x4[10];	invRotMat[11]=R4x4[11];
	invRotMat[12]=R4x4[12];	invRotMat[13]=R4x4[13];	invRotMat[14]=R4x4[14];	invRotMat[15]=R4x4[15];

	for (int i=0;i<4;i++)
	{
		newxyz[i]=0.0;
		for (int j=0;j<4;j++)
		{
			newxyz[i]+= invRotMat[i*4+j]*xyz[j];
		}
	}
	double tranMat[16];
	tranMat[ 0]=1.0;	tranMat[ 1]=0.0;	tranMat[ 2]=0.0;	tranMat[ 3]=-position[0];
	tranMat[ 4]=0.0;	tranMat[ 5]=1.0;	tranMat[ 6]=0.0;	tranMat[ 7]=-position[1];
	tranMat[ 8]=0.0;	tranMat[ 9]=0.0;	tranMat[10]=1.0;	tranMat[11]=-position[2];
	tranMat[12]=0.0;	tranMat[13]=0.0;	tranMat[14]=0.0;	tranMat[15]=1.0;
	for (int i=0;i<4;i++)
	{
		xyz[i]=0.0;
		for (int j=0;j<4;j++)
		{
			xyz[i]+= tranMat[i*4+j]*newxyz[j];
		}
	}

	/////////////////////////////////////////////////////

	for (int i=0;i<3;i++)
	{
		xyz[i]/=xyz[3];
	}
}

void Camera::World2Cam(double xyz[4])
{
	double newxyz[4];

	double tranMat[16];
	tranMat[ 0]=1.0;	tranMat[ 1]=0.0;	tranMat[ 2]=0.0;	tranMat[ 3]=position[0];
	tranMat[ 4]=0.0;	tranMat[ 5]=1.0;	tranMat[ 6]=0.0;	tranMat[ 7]=position[1];
	tranMat[ 8]=0.0;	tranMat[ 9]=0.0;	tranMat[10]=1.0;	tranMat[11]=position[2];
	tranMat[12]=0.0;	tranMat[13]=0.0;	tranMat[14]=0.0;	tranMat[15]=1.0;
	for (int i=0;i<4;i++)
	{
		newxyz[i]=0.0;
		for (int j=0;j<4;j++)
		{
			newxyz[i]+= tranMat[i*4+j]*xyz[j];
		}
	}

	for (int i=0;i<4;i++)
	{
		xyz[i]=0.0;
		for (int j=0;j<4;j++)
		{
			xyz[i]+= rotMat[i*4+j]*newxyz[j];
		}
	}

	for (int i=0;i<3;i++)
	{
		xyz[i]/=xyz[3];
	}
}

Camera::~Camera(void)
{
}

// P = KR[I|-C]
void Camera::Compose()
{
	double mm[2][3][4];
	int i,j,k;
	for (i=0;i<3;i++)
	{
		for (j=0;j<3;j++)
		{
			mm[0][i][j]=(i==j?1.0:0.0);
		}
		mm[0][i][3]=-position[i];
	}

	for (i=0;i<3;i++)
	{
		for (j=0;j<4;j++)
		{
			mm[1][i][j]=0.0;
			for (k=0;k<3;k++)
			{
				mm[1][i][j]+=R4x4[i*4+k]*mm[0][k][j];
			}
		}
	}

	double K[3][3];
	K[0][0]=f_len;	K[0][1]=0.0;	K[0][2]=u0;
	K[1][0]=0.0;	K[1][1]=f_len;	K[1][2]=v0;
	K[2][0]=0.0;	K[2][1]=0.0;	K[2][2]=1.0;

	for (i=0;i<3;i++)
	{
		for (j=0;j<4;j++)
		{
			mm[0][i][j]=0.0;
			for (k=0;k<3;k++)
			{
				mm[0][i][j]+=K[i][k]*mm[1][k][j];
			}

			matrix[i*4+j]=mm[0][i][j];
		}
	}
}