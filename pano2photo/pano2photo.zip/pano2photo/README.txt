open demo_main.m

This code is to demonstrate how to generate a crop from a full view panorama 
into a normal image, and how to warp it back.
--jianxiong

Citation:
J. Xiao, K. A. Ehinger, A. Oliva and A. Torralba.
Recognizing Scene Viewpoint using Panoramic Place Representation.
Proceedings of 25th IEEE Conference on Computer Vision and Pattern Recognition, 2012.
http://sun360.mit.edu


License: The MIT License (MIT) http://www.opensource.org/licenses/MIT

