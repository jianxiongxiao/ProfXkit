function varargout = ihashsum(varargin)
% VL_IHASHSUM
[varargout{1:nargout}] = vl_ihashsum(varargin{:});
