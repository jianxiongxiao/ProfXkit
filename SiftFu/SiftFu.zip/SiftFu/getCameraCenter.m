function Cw = getCameraCenter(camRtC2W)

Cw = camRtC2W(1:3,4);
