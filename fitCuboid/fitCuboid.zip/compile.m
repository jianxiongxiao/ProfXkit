

mex fitCuboidMex.cpp -I/usr/local/include -I/usr/include/eigen3 -Iceres-solver-1.3.0/include/ -Lceres-bin-1.3.0/lib/ -lceres -lpthread -lglog -lgflags -lcholmod -lccolamd -lcamd -lcolamd -lamd -llapack -lblas -lcxsparse -lgomp -lprotobuf

