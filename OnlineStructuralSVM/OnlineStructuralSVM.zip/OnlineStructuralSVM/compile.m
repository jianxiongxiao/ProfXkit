mex addcols.cc
mex qp.cc
